import sys
sys.stdout.reconfigure(encoding='utf-8')

import csv
import json

with open('dataset/sample_output.csv', 'r', encoding='utf-8') as f:
    samples = list(csv.DictReader(f))

statuses = [s['deletion_status'] for s in samples]
from collections import Counter
print("Status counts in sample:", Counter(statuses))

for s in samples:
    steps = json.loads(s['steps_json'])
    evs = set(st['evidence_id'] for st in steps if st.get('evidence_id'))
    phases = [st['phase'] for st in steps]
    ops = [st['operation'] for st in steps]
    print(f"{s['case_id']}: status={s['deletion_status']}, steps={len(steps)}, evs={evs}")
