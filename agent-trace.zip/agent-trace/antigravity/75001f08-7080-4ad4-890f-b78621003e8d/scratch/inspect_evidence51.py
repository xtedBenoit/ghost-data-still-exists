import sys
sys.stdout.reconfigure(encoding='utf-8')

import json

with open('dataset/evidence/records/customer_data_snapshot_bundle_20260915.json', 'r', encoding='utf-8') as f:
    bundle = json.load(f)

print("Keys in bundle:", bundle.keys())
for k in list(bundle.keys())[:5]:
    val = bundle[k]
    print(f"\nSection {k}: (type={type(val)})")
    if isinstance(val, dict):
        print("  Keys:", list(val.keys())[:5])
        for vk in list(val.keys())[:2]:
            print(f"    {vk}: {val[vk]}")
    elif isinstance(val, list):
        print(f"  Length: {len(val)}")
        print("  Sample 0:", val[0] if val else "empty")
