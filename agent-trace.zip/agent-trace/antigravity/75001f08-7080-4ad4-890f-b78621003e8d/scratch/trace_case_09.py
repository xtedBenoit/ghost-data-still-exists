import csv
import sys

sys.stdout.reconfigure(encoding='utf-8')

email = 'k.appiah88@gmail.com'
with open('dataset/user_identities.csv', 'r', encoding='utf-8') as f:
    for r in csv.DictReader(f):
        if r['email'] == email:
            print("user_identities:", r)

with open('dataset/system_activity.csv', 'r', encoding='utf-8') as f:
    for r in csv.DictReader(f):
        if email in str(r) or 'user_09' in str(r):
            print("system_activity:", r)
