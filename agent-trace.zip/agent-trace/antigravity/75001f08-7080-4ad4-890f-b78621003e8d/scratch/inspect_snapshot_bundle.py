import json
import sys
import glob

sys.stdout.reconfigure(encoding='utf-8')

bundles = glob.glob('dataset/evidence/records/snapshot_bundle_*.json')
print(f"Found {len(bundles)} snapshot bundles.")
if bundles:
    with open(bundles[0], 'r', encoding='utf-8') as f:
        data = json.load(f)
    print(f"Sample bundle {bundles[0]} keys: {list(data.keys())}")
    for k, v in data.items():
        if isinstance(v, dict):
            print(f"  {k} (dict, keys={list(v.keys())[:5]})")
        elif isinstance(v, list):
            print(f"  {k} (list, len={len(v)}, sample={v[0] if v else 'empty'})")
        else:
            print(f"  {k}: {v}")
