import sys
sys.stdout.reconfigure(encoding='utf-8')

import os
import csv

with open('dataset/evidence_files.csv', 'r', encoding='utf-8') as f:
    pdfs = [r for r in csv.DictReader(f) if r['file_path'].endswith('.pdf')]

for p in pdfs:
    print(p['file_id'], p['origin'], p['file_path'])
    # check raw bytes / text in PDF
    full_path = os.path.join('dataset', p['file_path'])
    with open(full_path, 'rb') as f:
        content = f.read()
        print(f"  Size: {len(content)} bytes")
        # Check if text is readable in stream
        import re
        text_parts = re.findall(rb'\(([^\)]+)\)', content)
        sample_text = b" ".join(text_parts[:10]).decode('latin1', errors='ignore')
        print(f"  Sample decoded text: {sample_text[:100]}")
