import csv
from collections import Counter
from pathlib import Path

with open('dataset/evidence_files.csv', 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    rows = list(reader)

exts = Counter(Path(r['file_path']).suffix for r in rows)
dirs = Counter(Path(r['file_path']).parent.name for r in rows)
origins = Counter(r['origin'] for r in rows)

print("Extensions:", exts)
print("Directories:", dirs)
print("Origins:", origins)
