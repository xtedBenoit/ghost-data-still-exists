import csv
with open('dataset/evidence_files.csv', 'r', encoding='utf-8') as f:
    images = [r for r in csv.DictReader(f) if r['file_path'].endswith('.png')]

for img in images:
    print(img['file_id'], img['origin'], img['captured_at'], img['file_path'])
