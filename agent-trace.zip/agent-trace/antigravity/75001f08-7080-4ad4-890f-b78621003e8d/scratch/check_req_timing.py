import csv
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/sample_deletion_requests.csv', 'r', encoding='utf-8') as f:
    sample_requests = list(csv.DictReader(f))

with open('dataset/system_activity.csv', 'r', encoding='utf-8') as f:
    acts = list(csv.DictReader(f))

for req in sample_requests[:5]:
    cid = req['case_id']
    rep_at = req['reported_at']
    req_at = req['requested_at']
    print(f"\n=== {cid}: requested_at={req_at}, reported_at={rep_at} ===")
    # Look for activities around requested_at to reported_at
    matching_acts = [a for a in acts if req_at <= a['event_time'] <= rep_at]
    print(f"Activities between requested_at and reported_at ({len(matching_acts)}):")
    for a in matching_acts:
        print(f"  {a['activity_id']} | {a['event_time']} | {a['event_type']} | {a['target_system']} | {a['resource_id']} | {a['reported_result']}")
