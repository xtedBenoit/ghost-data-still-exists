import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/evidence/logs/resource_lookup_trace_20260926_103856.log', 'r', encoding='utf-8') as f:
    for idx, l in enumerate(f):
        print(f"{idx+1:02d}: {l.strip()}")
