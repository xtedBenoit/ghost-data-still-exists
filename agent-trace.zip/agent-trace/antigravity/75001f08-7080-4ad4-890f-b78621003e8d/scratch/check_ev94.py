import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/evidence/logs/resource_lookup_trace_20260926_103856.log', 'r', encoding='utf-8') as f:
    for line in f:
        if any(term in line for term in ['user_43', 'account_7566', 'audit_record_2016', 'analytics_9406']):
            print(line.strip())
