with open('dataset/evidence/databases/customer_data_inventory_20260916.sql', 'r', encoding='utf-8') as f:
    text = f.read()

print("Is account_3960 in evidence_93?", "account_3960" in text)
print("Is audit_record_4902 in evidence_93?", "audit_record_4902" in text)
print("Is k.appiah88@gmail.com in evidence_93?", "k.appiah88@gmail.com" in text)
print("Is user_61 in evidence_93?", "user_61" in text)

import csv
with open('dataset/system_activity.csv', 'r', encoding='utf-8') as f:
    for row in csv.DictReader(f):
        if '3960' in row['resource_id'] or '4902' in row['resource_id']:
            print("system_activity:", row)
