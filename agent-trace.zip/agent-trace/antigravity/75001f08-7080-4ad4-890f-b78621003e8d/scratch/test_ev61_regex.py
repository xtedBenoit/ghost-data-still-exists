import csv
import json
import re

line1 = '2026-09-17T22:00:04Z level=DEBUG service=support_replica instance=support-eu-03 pod=replica-7c9f trace_id=tr-rp-002 event=contact_query_started lookup_key=nadia.ionescu@yahoo.com source=legacy_contact_index'
line2 = '2026-09-17T22:00:05Z level=INFO service=support_replica instance=support-eu-03 pod=replica-7c9f trace_id=tr-rp-002 event=contact_query_completed resource_id=support_002 rows=1 latency_ms=23'

matches1 = re.findall(r'(\w+)=(?:"([^"]*)"|([^\s]+))', line1)
print("matches1:", matches1)
kv1 = {m[0]: m[1] if m[1] else m[2] for m in matches1}
print("kv1:", kv1)

matches2 = re.findall(r'(\w+)=(?:"([^"]*)"|([^\s]+))', line2)
print("matches2:", matches2)
kv2 = {m[0]: m[1] if m[1] else m[2] for m in matches2}
print("kv2:", kv2)
