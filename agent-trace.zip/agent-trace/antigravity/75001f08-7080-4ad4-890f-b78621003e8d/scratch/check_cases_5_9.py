import csv
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/sample_deletion_requests.csv', 'r', encoding='utf-8') as f:
    for r in csv.DictReader(f):
        if r['case_id'] in ['case_05', 'case_06', 'case_07', 'case_08', 'case_09']:
            print(f"{r['case_id']} | {r['email']} | {r['requested_at']} | {r['reported_status']} | {r['audit_at']}")
