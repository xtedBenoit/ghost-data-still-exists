import csv
import json
import sqlite3
import os
import re
from pathlib import Path

# Load sample requests and reference outputs
with open('dataset/sample_deletion_requests.csv', 'r', encoding='utf-8') as f:
    sample_requests = list(csv.DictReader(f))

with open('dataset/sample_output.csv', 'r', encoding='utf-8') as f:
    sample_outputs = {r['case_id']: r for r in csv.DictReader(f)}

with open('dataset/evidence_files.csv', 'r', encoding='utf-8') as f:
    evidence_manifest = {r['file_id']: r for r in csv.DictReader(f)}

print(f"Loaded {len(sample_requests)} requests, {len(sample_outputs)} reference outputs.")
