import csv
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/deletion_requests.csv', 'r', encoding='utf-8') as f:
    requests = list(csv.DictReader(f))

# Keywords that indicate non-deletion intent:
# Access / Portability / Rectification / Marketing opt-out / Password reset
non_deletion_patterns = [
    "request access", "droit d'accès", "auskunft", "derecho de acceso", "acesso aos dados",
    "update my", "korrigieren sie", "rectification", "rectificar", "atualizar",
    "export of my", "copia completa", "datenübertragbarkeit", "portabilité", "exportar",
    "unsubscribe", "marketing", "promotional", "newsletter", "メルマガ", "publicitarios",
    "trouble logging", "reset my password", "redefinam minha senha", "mot de passe", "passwort"
]

deletion_keywords = [
    "delete", "erasure", "erase", "remove", "supprimer", "löschen", "eliminar",
    "cancelar", "forget", "oubli", "vergessen", "excluir", "削除", "effacer"
]

na_cases = []
for r in requests:
    text = r['request_text'].lower()
    is_na = False
    for pat in non_deletion_patterns:
        if pat in text:
            # Check if it also has an explicit deletion request
            has_del = any(dk in text for dk in deletion_keywords)
            if not has_del:
                is_na = True
                break
    if is_na:
        na_cases.append((r['case_id'], r['request_text'][:60]))

print(f"Total non-deletion cases detected: {len(na_cases)}")
for cid, txt in na_cases:
    print(f"  {cid}: {txt}")
