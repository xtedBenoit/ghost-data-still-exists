import sqlite3
import json
import sys

sys.stdout.reconfigure(encoding='utf-8')

con = sqlite3.connect(':memory:')
with open('dataset/evidence/databases/customer_data_read_replica_20260917.sql', 'r', encoding='utf-8') as f:
    con.executescript(f.read())

rows = con.execute("SELECT resource_id, origin_system, collection_name, record_json FROM customer_data_read_replica LIMIT 5").fetchall()
for r in rows:
    print(f"res={r[0]}, origin={r[1]}, coll={r[2]}")
    print("  json:", r[3])
