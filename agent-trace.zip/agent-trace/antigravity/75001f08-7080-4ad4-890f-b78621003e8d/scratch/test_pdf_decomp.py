import sys
sys.stdout.reconfigure(encoding='utf-8')

import zlib
import re

pdf_path = "dataset/evidence/documents/account_history_report_20260718.pdf"
with open(pdf_path, 'rb') as f:
    data = f.read()

# Find all streams in PDF
streams = re.findall(rb'stream[\r\n]+(.*?)[\r\n]+endstream', data, re.DOTALL)
print(f"Found {len(streams)} streams in {pdf_path}")
for i, s in enumerate(streams):
    try:
        decomp = zlib.decompress(s)
        # Check text in decompressed stream
        text_lines = re.findall(rb'\(([^\)]+)\)', decomp)
        if text_lines:
            text = b" ".join(text_lines).decode('latin1', errors='ignore')
            print(f"Stream {i} text: {text[:200]}")
        else:
            # Maybe plain text commands
            lines = decomp.decode('latin1', errors='ignore').splitlines()
            print(f"Stream {i} decompressed ({len(decomp)} bytes), sample:")
            for l in lines[:5]:
                print("   ", l[:80])
    except Exception as e:
        pass
