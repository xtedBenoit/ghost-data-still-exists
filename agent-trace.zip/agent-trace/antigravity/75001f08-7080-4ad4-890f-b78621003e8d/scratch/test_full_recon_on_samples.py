import csv
import json
import sqlite3
import os
import re
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8')

# 1. Identity mappings
identities_by_email = {}
identities_by_uid = {}
email_to_uid = {}
uid_to_emails = {}

with open('dataset/user_identities.csv', 'r', encoding='utf-8') as f:
    for r in csv.DictReader(f):
        uid = r['user_id'].strip()
        e = r['email'].strip().lower()
        identities_by_email[e] = r
        identities_by_uid[uid] = r
        email_to_uid[e] = uid
        uid_to_emails.setdefault(uid, set()).add(e)

with open('dataset/user_audit_log.csv', 'r', encoding='utf-8') as f:
    for r in csv.DictReader(f):
        uid = r['user_id'].strip()
        if r['field_name'] == 'email':
            for ev in [r['old_value'], r['new_value']]:
                if ev:
                    e = ev.strip().lower()
                    email_to_uid[e] = uid
                    uid_to_emails.setdefault(uid, set()).add(e)

print(f"Loaded {len(identities_by_uid)} users, {len(email_to_uid)} email mappings.")

# Function to resolve any identifier to uid
def resolve_uid(val):
    if not val:
        return None
    val_str = str(val).strip()
    if val_str in identities_by_uid:
        return val_str
    val_lower = val_str.lower()
    if val_lower in email_to_uid:
        return email_to_uid[val_lower]
    return None

# Load evidence manifest
with open('dataset/evidence_files.csv', 'r', encoding='utf-8') as f:
    evidence_manifest = {r['file_id']: r for r in csv.DictReader(f)}

print(f"Loaded {len(evidence_manifest)} evidence manifest records.")
