with open('dataset/evidence/records/customer_account_handover_20261001.txt', 'r', encoding='utf-8') as f:
    text = f.read()

print("Length of evidence_03:", len(text))
print("First 20 lines:")
for l in text.splitlines()[:20]:
    print(l)
