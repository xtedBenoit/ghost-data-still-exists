import csv
import json
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/sample_output.csv', 'r', encoding='utf-8') as f:
    sample_outputs = list(csv.DictReader(f))

with open('dataset/sample_deletion_requests.csv', 'r', encoding='utf-8') as f:
    sample_requests = {r['case_id']: r for r in csv.DictReader(f)}

print(f"{'case_id':<10} | {'status':<12} | {'audit_at':<20} | {'evidence_ids_cited'}")
print("-" * 75)

for row in sample_outputs:
    cid = row['case_id']
    status = row['deletion_status']
    steps = json.loads(row['steps_json'])
    ev_ids = sorted(list(set(s['evidence_id'] for s in steps if s['evidence_id'])))
    req = sample_requests[cid]
    print(f"{cid:<10} | {status:<12} | {req['audit_at']:<20} | {', '.join(ev_ids)}")
