import csv
import json
import sys

sys.stdout.reconfigure(encoding='utf-8')

case_26_resources = [
    'account_5684', 'audit_record_5416', 'support_4715',
    'analytics_4566', 'data_flow_6244', 'backup_3120'
]

print("--- Searching system_activity.csv for case_26 resources ---")
with open('dataset/system_activity.csv', 'r', encoding='utf-8') as f:
    for row in csv.DictReader(f):
        for res in case_26_resources:
            if res in row['resource_id'] or res in str(row['details']):
                print(f"system_activity: activity_id={row['activity_id']}, event_time={row['event_time']}, src={row['source_system']}, tgt={row['target_system']}, res={row['resource_id']}, op={row['event_type']}, result={row['reported_result']}, details={row['details']}")

print("\n--- Searching evidence_92 ---")
with open('dataset/evidence_files.csv', 'r', encoding='utf-8') as f:
    ev92 = next(r for r in csv.DictReader(f) if r['file_id'] == 'evidence_92')
print(f"evidence_92 path: {ev92['file_path']}, origin: {ev92['origin']}, captured_at: {ev92['captured_at']}")

with open('dataset/' + ev92['file_path'], 'r', encoding='utf-8') as f:
    ev92_data = json.load(f)

print(f"evidence_92 top keys: {list(ev92_data.keys())}")
if isinstance(ev92_data, dict):
    for k, v in ev92_data.items():
        v_str = str(v)
        matches = [res for res in case_26_resources if res in v_str]
        if matches:
            print(f"  Key {k} contains matches: {matches}")
