import csv
import json
import sqlite3
import os
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/sample_output.csv', 'r', encoding='utf-8') as f:
    sample_outputs = list(csv.DictReader(f))

with open('dataset/sample_deletion_requests.csv', 'r', encoding='utf-8') as f:
    sample_requests = {r['case_id']: r for r in csv.DictReader(f)}

with open('dataset/user_identities.csv', 'r', encoding='utf-8') as f:
    user_identities = {r['email'].lower(): r for r in csv.DictReader(f)}

with open('dataset/evidence_files.csv', 'r', encoding='utf-8') as f:
    evidence_manifest = {r['file_id']: r for r in csv.DictReader(f)}

print("Testing direct evidence extraction for sample cases...")
# For each sample case, find which evidence files mention the email or user_id
for row in sample_outputs:
    cid = row['case_id']
    req = sample_requests[cid]
    email = req['email'].lower()
    u = user_identities.get(email, {})
    uid = u.get('user_id', '')
    audit_at = req['audit_at']
    steps = json.loads(row['steps_json'])
    gold_ev_ids = sorted(list(set(s['evidence_id'] for s in steps if s['evidence_id'])))
    
    # Check which evidence files captured at <= audit_at contain email or uid
    matched_evs = []
    for fid, meta in evidence_manifest.items():
        if meta['captured_at'] <= audit_at:
            p = os.path.join('dataset', meta['file_path'])
            try:
                with open(p, 'r', encoding='utf-8', errors='ignore') as fp:
                    content = fp.read()
                    if email in content.lower() or (uid and uid in content):
                        matched_evs.append(fid)
            except Exception:
                pass
    print(f"[{cid}] Gold evs: {gold_ev_ids} | Matched evs: {matched_evs}")
