import csv

with open('dataset/system_activity.csv', 'r', encoding='utf-8') as f:
    for row in csv.DictReader(f):
        if '2026-09-06T10:' in row['event_time'] or '2026-09-06T11:' in row['event_time']:
            print(row['activity_id'], row['event_time'], row['event_type'], row['target_system'], row['resource_id'], row['reported_result'], row['details'])
