import csv
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/system_activity.csv', 'r', encoding='utf-8') as f:
    acts = list(csv.DictReader(f))

# Find idx of activity_3851
for idx, a in enumerate(acts):
    if a['activity_id'] in ['activity_3851', 'activity_3852']:
        for j in range(max(0, idx - 4), min(len(acts), idx + 5)):
            print(f"{acts[j]['activity_id']} | {acts[j]['event_time']} | {acts[j]['event_type']} | {acts[j]['source_system']} -> {acts[j]['target_system']} | res: {acts[j]['resource_id']} | det: {acts[j]['details']}")
        break
