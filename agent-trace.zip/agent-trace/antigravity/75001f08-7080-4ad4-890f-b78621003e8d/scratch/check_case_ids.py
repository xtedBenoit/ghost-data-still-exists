import sys
sys.stdout.reconfigure(encoding='utf-8')

import csv

with open('dataset/deletion_requests.csv', 'r', encoding='utf-8') as f:
    requests = list(csv.DictReader(f))

case_ids = [r['case_id'] for r in requests]
print(f"Min case_id: {case_ids[0]}, Max case_id: {case_ids[-1]}, Count: {len(case_ids)}")
print("Last 15 cases:")
for r in requests[-15:]:
    print(r['case_id'], r['email'], r['request_text'])
