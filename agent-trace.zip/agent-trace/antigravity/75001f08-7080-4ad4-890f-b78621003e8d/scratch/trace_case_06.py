import csv
import sys

sys.stdout.reconfigure(encoding='utf-8')

email = 'jonas.berg@outlook.com'
with open('dataset/user_identities.csv', 'r', encoding='utf-8') as f:
    for r in csv.DictReader(f):
        if r['email'] == email:
            print("user_identities:", r)

with open('dataset/user_audit_log.csv', 'r', encoding='utf-8') as f:
    for r in csv.DictReader(f):
        if email in str(r) or 'user_06' in str(r):
            print("user_audit_log:", r)

with open('dataset/system_activity.csv', 'r', encoding='utf-8') as f:
    for r in csv.DictReader(f):
        if email in str(r) or 'user_06' in str(r) or 'account_006' in str(r) or 'search_001' in str(r):
            print("system_activity:", r)
