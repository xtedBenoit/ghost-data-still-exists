import sys
sys.stdout.reconfigure(encoding='utf-8')

import json

with open('dataset/evidence/records/service_resource_export_20260915_114455.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

print("Type of data:", type(data))
if isinstance(data, dict):
    print("Keys:", list(data.keys())[:10])
    for k in list(data.keys())[:3]:
        print(f"Sample key {k}:", data[k])
elif isinstance(data, list):
    print("Length:", len(data))
    print("Sample items:", data[:3])
