import csv
import json
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/sample_output.csv', 'r', encoding='utf-8') as f:
    sample_outputs = list(csv.DictReader(f))

for row in sample_outputs:
    if row['deletion_status'] != 'COMPLETE':
        continue
    case_id = row['case_id']
    steps = json.loads(row['steps_json'])
    
    print(f"\n=== Case {case_id} (COMPLETE) ===")
    for s in steps:
        print(f"  {s['phase']} | {s['system_id']} | {s['resource_id']} | {s['operation']} | {s['state']} | {s['evidence_id']}")
