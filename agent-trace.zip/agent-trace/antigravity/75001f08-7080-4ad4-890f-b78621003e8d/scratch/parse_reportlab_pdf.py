with open("dataset/evidence/documents/account_history_report_20260718.pdf", 'rb') as f:
    data = f.read()

import re
matches = [m.start() for m in re.finditer(b'stream', data)]
print("Stream offsets:", matches[:10])

for off in matches[:5]:
    end = data.find(b'endstream', off)
    content_start = off + len(b'stream')
    if data[content_start:content_start+1] == b'\r': content_start += 1
    if data[content_start:content_start+1] == b'\n': content_start += 1
    content = data[content_start:end]
    import zlib
    try:
        decomp = zlib.decompress(content)
        print(f"\nDecompressed stream at {off} ({len(decomp)} bytes):")
        # Extract text strings: Tj or TJ operators
        texts = re.findall(rb'\(([^\)]*)\)\s*Tj', decomp)
        if texts:
            print("Texts:", [t.decode('latin1') for t in texts])
        else:
            print("Raw decomp sample:", decomp[:150])
    except Exception as e:
        print(f"Error at {off}:", e)
