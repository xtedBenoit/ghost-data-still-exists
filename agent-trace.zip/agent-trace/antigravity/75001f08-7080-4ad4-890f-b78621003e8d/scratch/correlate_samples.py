import sys
sys.stdout.reconfigure(encoding='utf-8')

import csv
import json

with open('dataset/sample_deletion_requests.csv', 'r', encoding='utf-8') as f:
    sample_reqs = {r['case_id']: r for r in csv.DictReader(f)}

with open('dataset/sample_output.csv', 'r', encoding='utf-8') as f:
    sample_outs = {r['case_id']: r for r in csv.DictReader(f)}

with open('dataset/user_identities.csv', 'r', encoding='utf-8') as f:
    identities = {r['email'].lower(): r for r in csv.DictReader(f)}

with open('dataset/user_audit_log.csv', 'r', encoding='utf-8') as f:
    audit_logs = list(csv.DictReader(f))

# Map historical emails to user_id
hist_email_to_user = {}
for log in audit_logs:
    if log['field_name'] == 'email':
        hist_email_to_user[log['old_value'].lower()] = log['user_id']
        hist_email_to_user[log['new_value'].lower()] = log['user_id']

for cid, req in sample_reqs.items():
    email = req['email'].lower()
    user = identities.get(email)
    uid = user['user_id'] if user else hist_email_to_user.get(email, "UNKNOWN")
    out = sample_outs[cid]
    status = out['deletion_status']
    steps = json.loads(out['steps_json'])
    print(f"\n{cid}: email={email} -> user_id={uid} | status={status}")
    for s in steps:
        print(f"  [{s['phase']}] {s['operation']} {s['system_id']}:{s['resource_id']} state={s['state']} ev={s['evidence_id']}")
