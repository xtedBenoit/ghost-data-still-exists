import csv
import json
import sqlite3
import os
import re
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8')

# Global map: user_id -> dict of (system_id, resource_id) -> list of observations
# where observation = {'evidence_id': fid, 'captured_at': ts, 'state': state, 'is_pii_exposed': bool, ...}

user_resources = {}

def add_obs(uid, sys_id, res_id, ev_id, cap_at, state, pii=False, rec_type=''):
    if not uid or not res_id:
        return
    user_resources.setdefault(uid, {}).setdefault((sys_id, res_id), []).append({
        'evidence_id': ev_id,
        'captured_at': cap_at,
        'state': state,
        'is_pii_exposed': pii,
        'record_type': rec_type
    })

print("Starting global resource indexing...")
