import csv
import sys
import sqlite3
import os

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/evidence_files.csv', 'r', encoding='utf-8') as f:
    sql_files = [r for r in csv.DictReader(f) if r['file_path'].endswith('.sql')]

print(f"Total SQL files: {len(sql_files)}")

# Test loading one sql file into in-memory sqlite
for item in sql_files[:3]:
    path = os.path.join('dataset', item['file_path'])
    con = sqlite3.connect(':memory:')
    with open(path, 'r', encoding='utf-8') as sf:
        sql_content = sf.read()
    con.executescript(sql_content)
    tables = [t[0] for t in con.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
    print(f"\n{item['file_id']} ({item['origin']}): tables = {tables}")
    for t in tables:
        count = con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
        cols = [c[1] for c in con.execute(f"PRAGMA table_info({t})").fetchall()]
        print(f"  Table {t}: count={count}, cols={cols}")
