import csv
import json
import os
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/sample_output.csv', 'r', encoding='utf-8') as f:
    sample_outputs = list(csv.DictReader(f))

with open('dataset/sample_deletion_requests.csv', 'r', encoding='utf-8') as f:
    sample_requests = {r['case_id']: r for r in csv.DictReader(f)}

with open('dataset/user_identities.csv', 'r', encoding='utf-8') as f:
    user_identities = {r['email'].lower(): r for r in csv.DictReader(f)}

# Find where each resource appears
all_steps = []
for row in sample_outputs:
    cid = row['case_id']
    req = sample_requests[cid]
    u = user_identities.get(req['email'].lower(), {})
    uid = u.get('user_id', '')
    steps = json.loads(row['steps_json'])
    for s in steps:
        all_steps.append((cid, req['email'], uid, s['phase'], s['system_id'], s['resource_id'], s['operation'], s['evidence_id']))

print(f"Total steps in sample outputs: {len(all_steps)}")
# Look at the first 10 steps
for st in all_steps[:15]:
    print(f"Case {st[0]} | user: {st[2]} | {st[3]} | {st[4]} | {st[5]} | {st[6]} | ev: {st[7]}")
