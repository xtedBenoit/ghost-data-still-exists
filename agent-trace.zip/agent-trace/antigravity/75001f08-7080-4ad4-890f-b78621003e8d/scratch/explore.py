import csv
import json

with open('dataset/sample_output.csv', 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    samples = list(reader)

evidence_used = set()
for s in samples:
    steps = json.loads(s['steps_json'])
    for step in steps:
        if step.get('evidence_id'):
            evidence_used.add(step['evidence_id'])

print('Evidence used in samples:', sorted(list(evidence_used)))

with open('dataset/evidence_files.csv', 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    evidence_files = {r['file_id']: r for r in reader}

for eid in sorted(list(evidence_used)):
    info = evidence_files.get(eid, {})
    print(f"{eid}: {info.get('file_path')} | {info.get('origin')} | {info.get('captured_at')}")
