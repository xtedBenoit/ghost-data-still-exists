import sys
sys.stdout.reconfigure(encoding='utf-8')

import csv
import json
import os

with open('dataset/sample_deletion_requests.csv', 'r', encoding='utf-8') as f:
    sample_reqs = {r['case_id']: r for r in csv.DictReader(f)}

with open('dataset/sample_output.csv', 'r', encoding='utf-8') as f:
    sample_outs = {r['case_id']: r for r in csv.DictReader(f)}

with open('dataset/user_identities.csv', 'r', encoding='utf-8') as f:
    identities = {r['email'].lower(): r for r in csv.DictReader(f)}

with open('dataset/user_audit_log.csv', 'r', encoding='utf-8') as f:
    audit_logs = list(csv.DictReader(f))

# Map historical emails/phones
user_by_email = dict(identities)
for a in audit_logs:
    uid = a['user_id']
    if a['field_name'] == 'email':
        user_by_email[a['old_value'].lower()] = {'user_id': uid, 'email': a['old_value']}
        user_by_email[a['new_value'].lower()] = {'user_id': uid, 'email': a['new_value']}

# Let's inspect each resource in each sample case
all_sample_resources = []
for cid, out in sample_outs.items():
    steps = json.loads(out['steps_json'])
    req = sample_reqs[cid]
    u = user_by_email.get(req['email'].lower(), {})
    uid = u.get('user_id', 'UNKNOWN')
    for s in steps:
        all_sample_resources.append({
            'case_id': cid,
            'user_id': uid,
            'req_email': req['email'],
            'system_id': s['system_id'],
            'resource_id': s['resource_id'],
            'operation': s['operation'],
            'phase': s['phase'],
            'evidence_id': s['evidence_id']
        })

print(f"Total steps across sample cases: {len(all_sample_resources)}")

# Check where each resource_id is found
with open('dataset/system_activity.csv', 'r', encoding='utf-8') as f:
    activities = list(csv.DictReader(f))

act_by_res = {}
for a in activities:
    act_by_res.setdefault(a['resource_id'], []).append(a)

found_in_act = 0
not_found_in_act = []
for r in all_sample_resources:
    res = r['resource_id']
    if res in act_by_res:
        found_in_act += 1
    else:
        not_found_in_act.append(r)

print(f"Found in system_activity: {found_in_act}/{len(all_sample_resources)}")
print(f"Not found in system_activity: {len(not_found_in_act)}")
unique_not_found = {r['resource_id']: r for r in not_found_in_act}
for res, r in unique_not_found.items():
    print(f"  Not in activity: {res} ({r['system_id']}) in {r['case_id']} (ev={r['evidence_id']})")
