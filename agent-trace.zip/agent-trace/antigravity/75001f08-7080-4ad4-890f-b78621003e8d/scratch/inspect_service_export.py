import json
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/evidence/records/service_resource_export_20260915_114455.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

for svc, records in data['service_exports'].items():
    print(f"\nService: {svc}, type: {type(records)}")
    if isinstance(records, dict):
        sample_key = list(records.keys())[0]
        print(f"  Sample key: {sample_key}, val: {records[sample_key]}")
    elif isinstance(records, list) and records:
        print(f"  Sample item: {records[0]}")
