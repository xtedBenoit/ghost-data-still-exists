import csv
import json
import sys

sys.stdout.reconfigure(encoding='utf-8')

# Run inspect script for case_10 and case_12 obs from test_complete_loader
import test_complete_loader as loader

for cid in ['case_10', 'case_12']:
    req = loader.sample_requests[int(cid.split('_')[1]) - 1]
    uid = loader.resolve_uid(req['email'].lower())
    obs = [o for o in loader.user_observations.get(uid, []) if o['captured_at'] <= req['audit_at']]
    print(f"\n=== {cid} ({uid}) ===")
    for o in obs:
        print(" ", o)

for cid in ['case_18', 'case_20']:
    req = loader.sample_requests[int(cid.split('_')[1]) - 1]
    uid = loader.resolve_uid(req['email'].lower())
    print(f"\n=== {cid}: email={req['email']}, uid={uid} ===")
    # search where email appears in logs
    for fid, meta in loader.evidence_manifest.items():
        if meta['captured_at'] <= req['audit_at']:
            p = 'dataset/' + meta['file_path']
            try:
                with open(p, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    if req['email'].lower() in content.lower() or (uid and uid in content):
                        print(f"  Found in {fid} ({meta['origin']})")
            except Exception:
                pass
