import csv, os, sys
from pypdf import PdfReader

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/evidence_files.csv', 'r', encoding='utf-8') as f:
    pdfs = [r for r in csv.DictReader(f) if r['file_path'].endswith('.pdf')]

for p in pdfs:
    path = os.path.join('dataset', p['file_path'])
    reader = PdfReader(path)
    full_text = '\n'.join(page.extract_text() or '' for page in reader.pages)
    print(f"=== {p['file_id']} | {p['origin']} | {p['captured_at']} ===")
    print(full_text)
    print("=" * 40)
