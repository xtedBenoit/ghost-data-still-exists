import json

with open('dataset/evidence/records/customer_data_snapshot_bundle_20260915.json', 'r', encoding='utf-8') as f:
    bundle = json.load(f)

for snap in bundle['snapshots']:
    print(f"Data store: {snap.get('data_store')}, collection: {snap.get('collection')}, records count: {len(snap.get('records', []))}")
    for r in snap.get('records', [])[:2]:
        print("  Sample record:", r)
