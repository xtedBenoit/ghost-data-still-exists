import sys
sys.stdout.reconfigure(encoding='utf-8')

import os
import csv
import json
import sqlite3
import re
from pathlib import Path

evidence_manifest_path = "dataset/evidence_files.csv"
with open(evidence_manifest_path, 'r', encoding='utf-8') as f:
    evidence_manifest = list(csv.DictReader(f))

print(f"Total evidence files in manifest: {len(evidence_manifest)}")
by_ext = {}
for e in evidence_manifest:
    ext = Path(e['file_path']).suffix.lower()
    by_ext.setdefault(ext, []).append(e)

for ext, items in by_ext.items():
    print(f"Extension {ext}: {len(items)} files")
