import csv
import json
import sqlite3
import os
import re
import sys
import hashlib
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8')

# Identity resolution
identities_by_email = {}
identities_by_uid = {}
email_to_uid = {}
hash_to_uid = {}
uid_to_emails = {}

def get_hash(email):
    return hashlib.sha256(email.strip().lower().encode('utf-8')).hexdigest()

with open('dataset/user_identities.csv', 'r', encoding='utf-8') as f:
    for r in csv.DictReader(f):
        uid = r['user_id'].strip()
        e = r['email'].strip().lower()
        ehash = r.get('email_hash', '').strip().lower() or get_hash(e)
        identities_by_email[e] = r
        identities_by_uid[uid] = r
        email_to_uid[e] = uid
        hash_to_uid[ehash] = uid
        uid_to_emails.setdefault(uid, set()).add(e)

with open('dataset/user_audit_log.csv', 'r', encoding='utf-8') as f:
    for r in csv.DictReader(f):
        uid = r['user_id'].strip()
        if r['field_name'] == 'email':
            for ev in [r['old_value'], r['new_value']]:
                if ev:
                    e = ev.strip().lower()
                    email_to_uid[e] = uid
                    hash_to_uid[get_hash(e)] = uid
                    uid_to_emails.setdefault(uid, set()).add(e)

def resolve_uid(val):
    if not val:
        return None
    s = str(val).strip()
    if s.lower() in ['null', 'none', '']:
        return None
    if s in identities_by_uid:
        return s
    sl = s.lower()
    if sl in email_to_uid:
        return email_to_uid[sl]
    if sl in hash_to_uid:
        return hash_to_uid[sl]
    return None

def normalize_sys_id(s):
    if not s:
        return ''
    sl = str(s).lower()
    if 'support' in sl:
        return 'support_platform'
    if 'search' in sl:
        return 'search_service'
    if 'account' in sl:
        return 'account_service'
    if 'analytics' in sl:
        return 'analytics_platform'
    if 'backup' in sl:
        return 'backup_service'
    if 'integration' in sl:
        return 'integration_service'
    if 'security' in sl:
        return 'security_service'
    if 'export' in sl:
        return 'export_service'
    if 'identity' in sl:
        return 'identity_service'
    return s

with open('dataset/evidence_files.csv', 'r', encoding='utf-8') as f:
    evidence_manifest = {r['file_id']: r for r in csv.DictReader(f)}

user_observations = {}

def record_obs(uid, ev_id, sys_id, res_id, rec_type, state, pii=False):
    if not uid or not res_id:
        return
    cap_at = evidence_manifest.get(ev_id, {}).get('captured_at', '')
    sys_id = normalize_sys_id(sys_id)
    user_observations.setdefault(uid, []).append({
        'evidence_id': ev_id,
        'captured_at': cap_at,
        'system_id': sys_id,
        'resource_id': res_id,
        'record_type': rec_type,
        'state': state,
        'is_pii_exposed': pii
    })

print("Parsing evidence files with full identity & syslog support...")

# 1. Parse JSON files
for fid, meta in evidence_manifest.items():
    fpath = os.path.join('dataset', meta['file_path'])
    origin = meta['origin']
    if not fpath.endswith('.json'):
        continue
    try:
        with open(fpath, 'r', encoding='utf-8') as jf:
            jdata = json.load(jf)
    except Exception:
        continue
    
    if origin == 'service_resource_export' and 'service_exports' in jdata:
        exports = jdata['service_exports']
        for item in exports.get('account_service', {}).get('profile_lookups', []):
            res_id = item.get('resource_id')
            code = item.get('status_code')
            prof = item.get('profile') or {}
            uid = resolve_uid(prof.get('customer_reference')) or resolve_uid(prof.get('email'))
            state = 'ABSENT' if code == 404 else 'PRESENT'
            record_obs(uid, fid, 'account_service', res_id, 'USER_PROFILE', state)
        
        for item in exports.get('analytics_platform', {}).get('profiles', []):
            res_id = item.get('resource_id')
            uid = resolve_uid(item.get('customer_reference')) or resolve_uid(item.get('email'))
            if item.get('email'):
                record_obs(uid, fid, 'analytics_platform', res_id, 'ANALYTICS_PROFILE', 'PRESENT', pii=True)
            else:
                record_obs(uid, fid, 'analytics_platform', res_id, 'ANALYTICS_PROFILE', 'ANONYMIZED', pii=False)

        for item in exports.get('backup_service', {}).get('restore_entries', []):
            res_id = item.get('resource_id')
            uid = resolve_uid(item.get('customer_reference')) or resolve_uid(item.get('customer_email'))
            allowed = item.get('restore_allowed', False)
            state = 'ACTIVE' if allowed else 'BLOCKED'
            record_obs(uid, fid, 'backup_service', res_id, 'BACKUP_ARCHIVE', state)

        for item in exports.get('export_service', {}).get('exports', []):
            res_id = item.get('resource_id')
            uid = resolve_uid(item.get('customer_reference')) or resolve_uid(item.get('owner_email'))
            record_obs(uid, fid, 'export_service', res_id, 'USER_EXPORT', 'PRESENT')

        for item in exports.get('integration_service', {}).get('connectors', []):
            res_id = item.get('resource_id')
            uid = resolve_uid(item.get('customer_reference')) or resolve_uid(item.get('customer_email'))
            enabled = item.get('enabled', False)
            state = 'ACTIVE' if enabled else 'DISABLED'
            record_obs(uid, fid, 'integration_service', res_id, 'ACTIVE_DATA_FLOW', state)

        for item in exports.get('search_service', {}).get('index_queries', []):
            res_id = item.get('resource_id')
            hits = item.get('hits', {})
            total = hits.get('total', 0)
            uid = resolve_uid(item.get('query'))
            if not uid and hits.get('documents'):
                doc = hits['documents'][0]
                uid = resolve_uid(doc.get('customer_reference')) or resolve_uid(doc.get('email'))
            state = 'PRESENT' if total > 0 else 'ABSENT'
            record_obs(uid, fid, 'search_service', res_id, 'SEARCH_INDEX_ENTRY', state)

        for item in exports.get('security_service', {}).get('audit_records', []):
            res_id = item.get('resource_id')
            uid = resolve_uid(item.get('subject_reference'))
            record_obs(uid, fid, 'security_service', res_id, 'SECURITY_AUDIT_LOG', 'PRESENT')

        for item in exports.get('support_platform', {}).get('tickets', []):
            res_id = item.get('resource_id')
            uid = resolve_uid(item.get('customer_reference')) or resolve_uid(item.get('requester_email'))
            if item.get('requester_email'):
                record_obs(uid, fid, 'support_platform', res_id, 'SUPPORT_MESSAGE', 'PRESENT', pii=True)
            else:
                record_obs(uid, fid, 'support_platform', res_id, 'SUPPORT_MESSAGE', 'REDACTED', pii=False)

    elif 'snapshot_bundle' in origin or 'snapshots' in jdata:
        for snap in jdata.get('snapshots', []):
            store = snap.get('data_store')
            for r in snap.get('records', []):
                res_id = r.get('resource_id')
                if store == 'identity_service':
                    uid = resolve_uid(r.get('subject_reference'))
                    has_pii = any(r.get(k) for k in ['name', 'email', 'phone', 'email_hash'])
                    state = 'PRESENT' if has_pii else 'REDACTED'
                    record_obs(uid, fid, 'identity_service', res_id, 'ACCOUNT_TOMBSTONE', state, pii=has_pii)
                elif store == 'security_service':
                    uid = resolve_uid(r.get('subject_reference'))
                    record_obs(uid, fid, 'security_service', res_id, 'SECURITY_AUDIT_LOG', 'PRESENT')
                elif store == 'account_service':
                    uid = resolve_uid(r.get('customer_reference')) or resolve_uid(r.get('email'))
                    record_obs(uid, fid, 'account_service', res_id, 'USER_PROFILE', 'PRESENT')
                elif store == 'search_service':
                    doc = r.get('document', {})
                    uid = resolve_uid(doc.get('customer_reference')) or resolve_uid(doc.get('email'))
                    record_obs(uid, fid, 'search_service', res_id, 'SEARCH_INDEX_ENTRY', 'PRESENT')

    elif origin == 'analytics_platform' and 'reports' in jdata:
        for rep in jdata.get('reports', []):
            res_id = rep.get('resource_id')
            uid = resolve_uid(rep.get('customer_reference')) or resolve_uid(rep.get('email'))
            if rep.get('email'):
                record_obs(uid, fid, 'analytics_platform', res_id, 'ANALYTICS_PROFILE', 'PRESENT', pii=True)
            else:
                record_obs(uid, fid, 'analytics_platform', res_id, 'ANALYTICS_PROFILE', 'ANONYMIZED', pii=False)

    elif origin == 'export_service':
        records = jdata.get('records', []) or jdata.get('export_jobs', [])
        for job in records:
            res_id = job.get('resource_id')
            uid = resolve_uid(job.get('customer_reference')) or resolve_uid(job.get('owner_email'))
            record_obs(uid, fid, 'export_service', res_id, 'USER_EXPORT', 'PRESENT')

# 2. Parse SQL files
for fid, meta in evidence_manifest.items():
    fpath = os.path.join('dataset', meta['file_path'])
    origin = meta['origin']
    if not fpath.endswith('.sql'):
        continue
    try:
        con = sqlite3.connect(':memory:')
        with open(fpath, 'r', encoding='utf-8') as sf:
            con.executescript(sf.read())
        tables = [t[0] for t in con.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
    except Exception:
        continue

    if 'customer_profiles_failover_replica' in tables:
        for row in con.execute("SELECT resource_id, user_id, email, account_status FROM customer_profiles_failover_replica").fetchall():
            res_id, r_uid, r_email, status = row
            uid = resolve_uid(r_uid) or resolve_uid(r_email)
            record_obs(uid, fid, 'account_service', res_id, 'USER_PROFILE', 'PRESENT')

    if origin == 'customer_data_inventory_capture':
        if 'customer_profiles' in tables:
            for row in con.execute("SELECT resource_id, customer_reference, email FROM customer_profiles").fetchall():
                uid = resolve_uid(row[1]) or resolve_uid(row[2])
                record_obs(uid, fid, 'account_service', row[0], 'USER_PROFILE', 'PRESENT')
        if 'customer_analytics_profiles' in tables:
            for row in con.execute("SELECT resource_id, customer_reference, email FROM customer_analytics_profiles").fetchall():
                uid = resolve_uid(row[1]) or resolve_uid(row[2])
                if row[2]:
                    record_obs(uid, fid, 'analytics_platform', row[0], 'ANALYTICS_PROFILE', 'PRESENT', pii=True)
                else:
                    record_obs(uid, fid, 'analytics_platform', row[0], 'ANALYTICS_PROFILE', 'ANONYMIZED', pii=False)
        if 'customer_search_documents' in tables:
            for row in con.execute("SELECT resource_id, customer_reference, email FROM customer_search_documents").fetchall():
                uid = resolve_uid(row[1]) or resolve_uid(row[2])
                record_obs(uid, fid, 'search_service', row[0], 'SEARCH_INDEX_ENTRY', 'PRESENT')
        if 'support_records' in tables:
            for row in con.execute("SELECT resource_id, customer_reference, requester_email FROM support_records").fetchall():
                uid = resolve_uid(row[1]) or resolve_uid(row[2])
                if row[2]:
                    record_obs(uid, fid, 'support_platform', row[0], 'SUPPORT_MESSAGE', 'PRESENT', pii=True)
                else:
                    record_obs(uid, fid, 'support_platform', row[0], 'SUPPORT_MESSAGE', 'REDACTED', pii=False)
        if 'customer_exports' in tables:
            for row in con.execute("SELECT resource_id, customer_reference, owner_email FROM customer_exports").fetchall():
                uid = resolve_uid(row[1]) or resolve_uid(row[2])
                record_obs(uid, fid, 'export_service', row[0], 'USER_EXPORT', 'PRESENT')
        if 'connector_subscriptions' in tables:
            for row in con.execute("SELECT resource_id, customer_reference, customer_email, enabled FROM connector_subscriptions").fetchall():
                uid = resolve_uid(row[1]) or resolve_uid(row[2])
                state = 'ACTIVE' if row[3] == 1 else 'DISABLED'
                record_obs(uid, fid, 'integration_service', row[0], 'ACTIVE_DATA_FLOW', state)
        if 'backup_restore_entries' in tables:
            for row in con.execute("SELECT resource_id, customer_reference, customer_email, restore_allowed FROM backup_restore_entries").fetchall():
                uid = resolve_uid(row[1]) or resolve_uid(row[2])
                state = 'ACTIVE' if row[3] == 1 else 'BLOCKED'
                record_obs(uid, fid, 'backup_service', row[0], 'BACKUP_ARCHIVE', state)
        if 'security_audit_records' in tables:
            for row in con.execute("SELECT resource_id, subject_reference FROM security_audit_records").fetchall():
                uid = resolve_uid(row[1])
                record_obs(uid, fid, 'security_service', row[0], 'SECURITY_AUDIT_LOG', 'PRESENT')

    if 'customer_data_read_replica' in tables:
        for row in con.execute("SELECT resource_id, origin_system, record_json FROM customer_data_read_replica").fetchall():
            res_id, orig_sys, rec_str = row
            try:
                rec = json.loads(rec_str)
                uid = resolve_uid(rec.get('customer_reference')) or resolve_uid(rec.get('user_id')) or resolve_uid(rec.get('email'))
                if orig_sys == 'account_service':
                    record_obs(uid, fid, 'account_service', res_id, 'USER_PROFILE', 'PRESENT')
                elif orig_sys == 'search_service':
                    record_obs(uid, fid, 'search_service', res_id, 'SEARCH_INDEX_ENTRY', 'PRESENT')
                elif orig_sys == 'analytics_platform':
                    has_pii = bool(rec.get('email') or rec.get('phone'))
                    state = 'PRESENT' if has_pii else 'ANONYMIZED'
                    record_obs(uid, fid, 'analytics_platform', res_id, 'ANALYTICS_PROFILE', state, pii=has_pii)
                elif orig_sys == 'support_platform':
                    has_pii = bool(rec.get('requester_email') or rec.get('requester_phone'))
                    state = 'PRESENT' if has_pii else 'REDACTED'
                    record_obs(uid, fid, 'support_platform', res_id, 'SUPPORT_MESSAGE', state, pii=has_pii)
            except Exception:
                pass

    if 'search_documents_primary' in tables:
        for row in con.execute("SELECT resource_id, email FROM search_documents_primary").fetchall():
            uid = resolve_uid(row[1])
            record_obs(uid, fid, 'search_service', row[0], 'SEARCH_INDEX_ENTRY', 'PRESENT')

# 3. Parse evidence_03
try:
    with open('dataset/evidence/records/customer_account_handover_20261001.txt', 'r', encoding='utf-8') as hf:
        for line in hf:
            line = line.strip()
            if not line.startswith('- '):
                continue
            parts = [p.strip() for p in line[2:].split('|')]
            if len(parts) >= 6:
                ts, sys_id, res_id, rec_type, status, ident = parts[:6]
                uid = resolve_uid(ident)
                if status == 'NOT_FOUND':
                    record_obs(uid, 'evidence_03', sys_id, res_id, rec_type, 'ABSENT')
                elif status == 'IDENTIFIABLE':
                    record_obs(uid, 'evidence_03', sys_id, res_id, rec_type, 'PRESENT', pii=True)
                elif status == 'ANONYMIZED':
                    record_obs(uid, 'evidence_03', sys_id, res_id, rec_type, 'ANONYMIZED', pii=False)
                elif status == 'ACTIVE':
                    record_obs(uid, 'evidence_03', sys_id, res_id, rec_type, 'ACTIVE')
                elif status == 'BLOCKED':
                    record_obs(uid, 'evidence_03', sys_id, res_id, rec_type, 'BLOCKED')
                elif status == 'DISABLED':
                    record_obs(uid, 'evidence_03', sys_id, res_id, rec_type, 'DISABLED')
                elif status == 'REDACTED':
                    record_obs(uid, 'evidence_03', sys_id, res_id, rec_type, 'REDACTED', pii=False)
                elif status == 'FOUND':
                    record_obs(uid, 'evidence_03', sys_id, res_id, rec_type, 'PRESENT')
except Exception as e:
    pass

# 4. Parse Static Facts
with open('code/config/image_facts.json', 'r', encoding='utf-8') as f:
    img_facts = json.load(f)
    for fid, item in img_facts.items():
        for rec in item.get('records', []):
            uid = resolve_uid(rec.get('user_id')) or resolve_uid(rec.get('email'))
            sys_id = rec.get('system_id')
            res_id = rec.get('resource_id')
            rec_type = rec.get('record_type')
            state = rec.get('state')
            pii = not rec.get('is_redacted', True) if 'is_redacted' in rec else (not rec.get('is_anonymized', True) if 'is_anonymized' in rec else False)
            record_obs(uid, fid, sys_id, res_id, rec_type, state, pii=pii)

with open('code/config/pdf_facts.json', 'r', encoding='utf-8') as f:
    pdf_facts = json.load(f)
    for fid, item in pdf_facts.items():
        for rec in item.get('records', []):
            uid = resolve_uid(rec.get('user_id')) or resolve_uid(rec.get('email'))
            sys_id = rec.get('system_id')
            res_id = rec.get('resource_id')
            rec_type = rec.get('record_type')
            state = rec.get('state')
            pii = not rec.get('is_redacted', True) if 'is_redacted' in rec else False
            record_obs(uid, fid, sys_id, res_id, rec_type, state, pii=pii)

# 5. Parse ALL 26 Logs dynamically
log_evidence = [r for r in evidence_manifest.values() if r['file_path'].endswith('.log')]
for meta in log_evidence:
    fid = meta['file_id']
    p = os.path.join('dataset', meta['file_path'])
    try:
        with open(p, 'r', encoding='utf-8', errors='ignore') as lf:
            lines = lf.readlines()
        traces = {}
        for line in lines:
            line_str = line.strip()
            # Try JSON line
            if '{' in line_str and '}' in line_str:
                json_part = line_str[line_str.find('{'):line_str.rfind('}')+1]
                try:
                    ld = json.loads(json_part)
                    tr = ld.get('trace_id')
                    res = ld.get('resource_id')
                    svc = ld.get('service') or ld.get('logger')
                    ev = str(ld.get('event', ''))
                    
                    # Search all possible identity fields in JSON
                    ident = None
                    for k in ['lookup_key', 'subject_key', 'match_key', 'correlation_key', 'subject_ref', 'customer_reference', 'user_id', 'email', 'requester_email', 'matched_value']:
                        val = ld.get(k)
                        if val and str(val).lower() not in ['null', 'none', '']:
                            ident = val
                            break
                    if tr and ident:
                        traces.setdefault(tr, {})['ident'] = ident
                    if tr and res:
                        traces.setdefault(tr, {})['res'] = res
                    if tr and svc:
                        traces.setdefault(tr, {})['svc'] = svc
                    
                    # Check event outcomes
                    u_ident = ident or (traces.get(tr, {}).get('ident') if tr else None)
                    uid = resolve_uid(u_ident)
                    res_id = res or (traces.get(tr, {}).get('res') if tr else None)
                    sys_id = normalize_sys_id(svc or (traces.get(tr, {}).get('svc') if tr else ''))
                    
                    if uid and res_id:
                        # Determine state
                        if '404' in str(ld.get('http_status')) or ld.get('rows') == '0' or ld.get('rows') == 0:
                            record_obs(uid, fid, sys_id, res_id, 'USER_PROFILE', 'ABSENT')
                        elif ld.get('eligible') == 'true' and ld.get('deletion_block') == 'false':
                            record_obs(uid, fid, sys_id, res_id, 'BACKUP_ARCHIVE', 'ACTIVE')
                        elif ld.get('enabled') == 'true' or ld.get('enabled') is True:
                            record_obs(uid, fid, sys_id, res_id, 'ACTIVE_DATA_FLOW', 'ACTIVE')
                        elif 'pii_scan' in ev or ld.get('detector') == 'direct_identifier':
                            record_obs(uid, fid, sys_id, res_id, 'SUPPORT_MESSAGE', 'PRESENT', pii=True)
                        elif ld.get('result') == 'hit' or ld.get('total_hits', 0) > 0 or ld.get('rows') == '1' or ld.get('rows') == 1:
                            if 'search' in sys_id:
                                record_obs(uid, fid, sys_id, res_id, 'SEARCH_INDEX_ENTRY', 'PRESENT')
                            elif 'analytics' in sys_id:
                                record_obs(uid, fid, sys_id, res_id, 'ANALYTICS_PROFILE', 'PRESENT')
                            elif 'support' in sys_id:
                                record_obs(uid, fid, sys_id, res_id, 'SUPPORT_MESSAGE', 'PRESENT', pii=True)
                            elif 'account' in sys_id:
                                record_obs(uid, fid, sys_id, res_id, 'USER_PROFILE', 'PRESENT')
                            elif 'security' in sys_id:
                                record_obs(uid, fid, sys_id, res_id, 'SECURITY_AUDIT_LOG', 'PRESENT')
                except Exception:
                    pass
            else:
                # Key-value / Syslog line
                matches = re.findall(r'(\w+)=(?:"([^"]*)"|([^\s]+))', line_str)
                kv = {m[0]: m[1] if m[1] else m[2] for m in matches}
                tr = kv.get('trace_id')
                res = kv.get('resource_id')
                svc = kv.get('service')
                ev = kv.get('event', '')
                ident = None
                for k in ['lookup_key', 'subject_key', 'match_key', 'correlation_key', 'subject_reference', 'customer_reference', 'user_id', 'email', 'requester_email', 'matched_value']:
                    val = kv.get(k)
                    if val and str(val).lower() not in ['null', 'none', '']:
                        ident = val
                        break
                if tr and ident:
                    traces.setdefault(tr, {})['ident'] = ident
                if tr and res:
                    traces.setdefault(tr, {})['res'] = res
                if tr and svc:
                    traces.setdefault(tr, {})['svc'] = svc

                u_ident = ident or (traces.get(tr, {}).get('ident') if tr else None)
                uid = resolve_uid(u_ident)
                res_id = res or (traces.get(tr, {}).get('res') if tr else None)
                sys_id = normalize_sys_id(svc or (traces.get(tr, {}).get('svc') if tr else ''))

                if uid and res_id:
                    if kv.get('http_status') == '404' or kv.get('rows') == '0':
                        record_obs(uid, fid, sys_id, res_id, 'USER_PROFILE', 'ABSENT')
                    elif kv.get('eligible') == 'true' and kv.get('deletion_block') == 'false':
                        record_obs(uid, fid, sys_id, res_id, 'BACKUP_ARCHIVE', 'ACTIVE')
                    elif kv.get('enabled') == 'true':
                        record_obs(uid, fid, sys_id, res_id, 'ACTIVE_DATA_FLOW', 'ACTIVE')
                    elif 'pii_scan' in ev or kv.get('detector') == 'direct_identifier':
                        record_obs(uid, fid, sys_id, res_id, 'SUPPORT_MESSAGE', 'PRESENT', pii=True)
                    elif kv.get('marker_found') == 'false' or kv.get('rows') == '1' or kv.get('result') == 'hit':
                        if 'support' in sys_id:
                            record_obs(uid, fid, sys_id, res_id, 'SUPPORT_MESSAGE', 'PRESENT')
                        elif 'search' in sys_id:
                            record_obs(uid, fid, sys_id, res_id, 'SEARCH_INDEX_ENTRY', 'PRESENT')
                        elif 'analytics' in sys_id:
                            record_obs(uid, fid, sys_id, res_id, 'ANALYTICS_PROFILE', 'PRESENT')
                        elif 'account' in sys_id:
                            record_obs(uid, fid, sys_id, res_id, 'USER_PROFILE', 'PRESENT')
                        elif 'security' in sys_id:
                            record_obs(uid, fid, sys_id, res_id, 'SECURITY_AUDIT_LOG', 'PRESENT')
    except Exception as e:
        pass

# Evaluate against sample outputs
with open('dataset/sample_output.csv', 'r', encoding='utf-8') as f:
    sample_outputs = {r['case_id']: r for r in csv.DictReader(f)}

with open('dataset/sample_deletion_requests.csv', 'r', encoding='utf-8') as f:
    sample_requests = list(csv.DictReader(f))

correct_statuses = 0
total_cases = len(sample_requests)

for req in sample_requests:
    cid = req['case_id']
    email = req['email'].lower()
    audit_at = req['audit_at']
    uid = resolve_uid(email)
    gold = sample_outputs[cid]
    gold_status = gold['deletion_status']
    
    obs_list = [o for o in user_observations.get(uid, []) if o['captured_at'] <= audit_at]
    
    has_violation = False
    for o in obs_list:
        if o['system_id'] == 'account_service' and o['state'] == 'PRESENT':
            has_violation = True
        elif o['system_id'] == 'search_service' and o['state'] == 'PRESENT':
            has_violation = True
        elif o['system_id'] == 'export_service' and o['state'] == 'PRESENT':
            has_violation = True
        elif o['system_id'] == 'support_platform' and o['state'] == 'PRESENT':
            has_violation = True
        elif o['system_id'] == 'analytics_platform' and o['state'] == 'PRESENT':
            has_violation = True
        elif o['system_id'] == 'backup_service' and o['state'] == 'ACTIVE':
            has_violation = True
        elif o['system_id'] == 'integration_service' and o['state'] == 'ACTIVE':
            has_violation = True
        elif o['is_pii_exposed']:
            has_violation = True
    
    pred_status = 'INCOMPLETE' if has_violation else 'COMPLETE'
    is_match = (pred_status == gold_status)
    if is_match:
        correct_statuses += 1
    
    print(f"[{cid}] Pred: {pred_status:<10} | Gold: {gold_status:<10} | Match: {is_match} | Obs count: {len(obs_list)}")

print(f"\nStatus Accuracy on 32 samples: {correct_statuses}/{total_cases} ({correct_statuses/total_cases*100:.1f}%)")
