import csv
import json
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/sample_output.csv', 'r', encoding='utf-8') as f:
    sample_outputs = list(csv.DictReader(f))

for row in sample_outputs:
    if row['deletion_status'] != 'INCOMPLETE':
        continue
    case_id = row['case_id']
    steps = json.loads(row['steps_json'])
    
    findings = [s for s in steps if s['phase'] == 'FINDING']
    remediations = [s for s in steps if s['phase'] == 'REMEDIATION']
    verifications = [s for s in steps if s['phase'] == 'VERIFICATION']
    
    print(f"\n=== Case {case_id} ===")
    print(f"Findings ({len(findings)}):")
    for f in findings:
        print(f"  {f['system_id']} | {f['resource_id']} | {f['operation']} | {f['evidence_id']}")
    print(f"Remediations ({len(remediations)}):")
    for r in remediations:
        print(f"  {r['system_id']} | {r['resource_id']} | {r['operation']}")
    print(f"Verifications ({len(verifications)}):")
    for v in verifications:
        print(f"  {v['system_id']} | {v['resource_id']} | {v['operation']}")
