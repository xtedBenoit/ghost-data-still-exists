import sys
sys.stdout.reconfigure(encoding='utf-8')

import csv

with open('dataset/deletion_requests.csv', 'r', encoding='utf-8') as f:
    requests = list(csv.DictReader(f))

non_deletion_keywords = [
    'access', 'export', 'download', 'copy', 'rectif', 'correct', 'update', 'opt-out', 'marketing', 'unsubscribe',
    'information', 'portable', 'portability', 'show me', 'send me a copy'
]

potential_na = []
for r in requests:
    text = r['request_text'].lower()
    # Check if deletion words are absent
    has_delete = any(w in text for w in ['delet', 'eras', 'close', 'remov', 'supprim', 'eliminar', 'suppression', 'eliminaci', '削除', 'supprimer'])
    if not has_delete:
        potential_na.append(r)

print(f"Requests without obvious delete keywords: {len(potential_na)}")
for r in potential_na[:10]:
    print(f"{r['case_id']} | {r['email']} | {r['request_text']}")
