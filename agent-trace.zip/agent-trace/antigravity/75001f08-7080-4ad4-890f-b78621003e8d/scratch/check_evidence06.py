with open('dataset/evidence/logs/structured_service_events_eu_west_20260918.log', 'r', encoding='utf-8') as f:
    for line in f:
        if 'audit_record_4902' in line or 'user_61' in line or 'k.appiah88@gmail.com' in line:
            print(line.strip())
