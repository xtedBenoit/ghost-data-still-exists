import sys
sys.stdout.reconfigure(encoding='utf-8')

import csv

with open('dataset/deletion_requests.csv', 'r', encoding='utf-8') as f:
    requests = list(csv.DictReader(f))

print(f"Total requests: {len(requests)}")

# Let's inspect some sample request texts to see various types
import random
random.seed(42)

for r in requests[:20]:
    print(f"{r['case_id']} | {r['email']} | {r['reported_status']} | Text: {r['request_text'][:80]}...")
