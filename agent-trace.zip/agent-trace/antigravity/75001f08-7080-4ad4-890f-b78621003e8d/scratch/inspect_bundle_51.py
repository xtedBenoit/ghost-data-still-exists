import json
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/evidence/records/customer_data_snapshot_bundle_20260915.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

print("evidence_51 keys:", list(data.keys()))
for k in data.keys():
    val = data[k]
    print(f"Key: {k}, type: {type(val)}")
    if isinstance(val, dict):
        print(f"  subkeys: {list(val.keys())[:5]}")
    elif isinstance(val, list):
        print(f"  len: {len(val)}, sample: {val[0] if val else 'empty'}")
