import csv
import sys
import sqlite3
import os

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/evidence_files.csv', 'r', encoding='utf-8') as f:
    sql_files = [r for r in csv.DictReader(f) if r['file_path'].endswith('.sql')]

table_schemas = {}
for item in sql_files:
    path = os.path.join('dataset', item['file_path'])
    con = sqlite3.connect(':memory:')
    with open(path, 'r', encoding='utf-8') as sf:
        con.executescript(sf.read())
    tables = [t[0] for t in con.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
    for t in tables:
        cols = tuple(c[1] for c in con.execute(f"PRAGMA table_info({t})").fetchall())
        table_schemas.setdefault((item['origin'], t), cols)

print(f"Unique (origin, table) schemas across all 24 SQL files:")
for (origin, t), cols in sorted(table_schemas.items()):
    print(f"Origin: {origin} | Table: {t} | Cols: {cols}")
