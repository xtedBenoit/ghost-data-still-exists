import csv
import sys
from datetime import datetime

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/system_activity.csv', 'r', encoding='utf-8') as f:
    acts = [r for r in csv.DictReader(f) if r['source_system'] == 'deletion_worker']

print(f"Total deletion worker activities: {len(acts)}")

# Group activities that are within 2 hours of each other
# Let's inspect the intervals
timestamps = [datetime.fromisoformat(a['event_time'].replace('Z', '+00:00')) for a in acts]
diffs = [(timestamps[i] - timestamps[i-1]).total_seconds() for i in range(1, len(timestamps))]

batches = []
curr_batch = [acts[0]]
for i in range(1, len(acts)):
    dt = (timestamps[i] - timestamps[i-1]).total_seconds()
    # If gap is greater than 30 minutes, new batch
    if dt > 1800:
        batches.append(curr_batch)
        curr_batch = [acts[i]]
    else:
        curr_batch.append(acts[i])
batches.append(curr_batch)

print(f"Discovered {len(batches)} deletion batches in system_activity.csv!")
for idx, b in enumerate(batches[:10]):
    res_list = [a['resource_id'] for a in b]
    print(f"Batch {idx+1} ({len(b)} events, start={b[0]['event_time']}): {res_list}")
