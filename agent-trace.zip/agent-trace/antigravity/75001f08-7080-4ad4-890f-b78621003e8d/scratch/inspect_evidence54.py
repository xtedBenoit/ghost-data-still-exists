with open('dataset/evidence/databases/customer_accounts_failover_replica_20260902.sql', 'r', encoding='utf-8') as f:
    lines = [f.readline() for _ in range(30)]

for l in lines:
    print(l.strip())
