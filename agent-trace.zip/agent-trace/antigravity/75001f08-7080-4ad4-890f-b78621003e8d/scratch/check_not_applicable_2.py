import sys
sys.stdout.reconfigure(encoding='utf-8')

import csv

with open('dataset/deletion_requests.csv', 'r', encoding='utf-8') as f:
    requests = list(csv.DictReader(f))

# Let's inspect all 30 potential non-delete requests
for r in requests:
    text = r['request_text'].lower()
    has_delete = any(w in text for w in ['delet', 'eras', 'close', 'remov', 'supprim', 'eliminar', 'suppression', 'eliminaci', '削除', 'supprimer', 'exclusão', 'exclusao', '삭제'])
    if not has_delete:
        print(f"STILL NO DELETE KEYWORD: {r['case_id']} | {r['email']} | {r['request_text']}")
