import sys
sys.stdout.reconfigure(encoding='utf-8')

import os
import csv
import re
from pathlib import Path

with open('dataset/evidence_files.csv', 'r', encoding='utf-8') as f:
    files = [r for r in csv.DictReader(f) if r['file_path'].endswith('.sql')]

print(f"Total SQL files: {len(files)}")
table_sets = {}
for f in files:
    fpath = os.path.join('dataset', f['file_path'])
    tables = []
    with open(fpath, 'r', encoding='utf-8') as sf:
        for line in sf:
            m = re.search(r'CREATE TABLE (?:IF NOT EXISTS )?([a-zA-Z0-9_]+)', line, re.IGNORECASE)
            if m:
                tables.append(m.group(1))
    tkey = tuple(sorted(tables))
    table_sets.setdefault(tkey, []).append((f['file_id'], f['origin'], f['file_path']))

for tkey, flist in table_sets.items():
    print(f"\nTables: {tkey} ({len(flist)} files):")
    for fid, orig, p in flist[:3]:
        print(f"  {fid} | {orig} | {p}")
    if len(flist) > 3:
        print(f"  ... and {len(flist) - 3} more")
