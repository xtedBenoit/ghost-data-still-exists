import csv
import json
import sqlite3
import os
import sys

sys.stdout.reconfigure(encoding='utf-8')

sys.path.append('C:/Users/Develo/.gemini\antigravity/brain/75001f08-7080-4ad4-890f-b78621003e8d/scratch')
import test_complete_loader as loader

# Find account_id for each sample case from gold
with open('dataset/sample_output.csv', 'r', encoding='utf-8') as f:
    sample_outputs = {r['case_id']: r for r in csv.DictReader(f)}

with open('dataset/sample_deletion_requests.csv', 'r', encoding='utf-8') as f:
    sample_requests = list(csv.DictReader(f))

gold_accounts = {}
for cid, r in sample_outputs.items():
    steps = json.loads(r['steps_json'])
    for s in steps:
        if s['system_id'] == 'account_service':
            gold_accounts[cid] = s['resource_id']
            break

print("Gold accounts count:", len(gold_accounts))

# Now let's see how our loader can discover that account_id:
# 1. From user_observations where system_id == 'account_service'
# 2. From system_activity.csv
# 3. From pattern user_XX -> account_XXX (for case 1..10)

user_account_map = {}
with open('dataset/system_activity.csv', 'r', encoding='utf-8') as f:
    for r in csv.DictReader(f):
        res = r['resource_id']
        if res.startswith('account_'):
            for uid, emails in loader.uid_to_emails.items():
                if uid in r['details'] or any(e in r['details'] for e in emails):
                    user_account_map[uid] = res

discovered_accounts = {}
for req in sample_requests:
    cid = req['case_id']
    uid = loader.resolve_uid(req['email'])
    
    # Check obs
    obs_accs = [o['resource_id'] for o in loader.user_observations.get(uid, []) if o['system_id'] == 'account_service']
    if obs_accs:
        discovered_accounts[cid] = obs_accs[0]
    elif uid in user_account_map:
        discovered_accounts[cid] = user_account_map[uid]
    elif uid and uid.startswith('user_') and int(uid.split('_')[1]) <= 10:
        discovered_accounts[cid] = f"account_{int(uid.split('_')[1]):03d}"

matches = sum(1 for cid in gold_accounts if discovered_accounts.get(cid) == gold_accounts[cid])
print(f"Discovered accounts matched: {matches}/{len(gold_accounts)}")
for cid in gold_accounts:
    if discovered_accounts.get(cid) != gold_accounts[cid]:
        print(f"  Mismatch {cid}: gold={gold_accounts[cid]}, disc={discovered_accounts.get(cid)}")
