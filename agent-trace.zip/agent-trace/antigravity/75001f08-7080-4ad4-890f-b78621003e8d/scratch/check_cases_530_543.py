import sys
sys.stdout.reconfigure(encoding='utf-8')

import csv

with open('dataset/deletion_requests.csv', 'r', encoding='utf-8') as f:
    requests = {r['case_id']: r for r in csv.DictReader(f)}

for i in range(530, 544):
    cid = f"case_{i}"
    if cid in requests:
        r = requests[cid]
        print(cid, r['email'], r['request_text'])
