import csv
with open('dataset/user_identities.csv', 'r', encoding='utf-8') as f:
    for row in csv.DictReader(f):
        if row['user_id'] == 'user_43':
            print("user_identities:", row)

with open('dataset/user_audit_log.csv', 'r', encoding='utf-8') as f:
    for row in csv.DictReader(f):
        if row['user_id'] == 'user_43':
            print("user_audit_log:", row)
