with open("dataset/evidence/documents/account_history_report_20260718.pdf", 'rb') as f:
    header = f.read(500)
    print("Header:", header[:200])
