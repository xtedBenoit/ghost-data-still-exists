import csv
import json
import os
import sys

sys.stdout.reconfigure(encoding='utf-8')

sys.path.append('C:/Users/Develo/.gemini\antigravity/brain/75001f08-7080-4ad4-890f-b78621003e8d/scratch')
import test_complete_loader as loader

PHASE_ORDER = {'FINDING': 1, 'REMEDIATION': 2, 'VERIFICATION': 3}
OP_ORDER = {
    'REPORT_REMAINING_RECORD': 1,
    'REPORT_EXPOSED_PII': 2,
    'REPORT_ACTIVE_DATA_FLOW': 3,
    'REPORT_RESTORE_RISK': 4,
    'DISABLE_DATA_FLOW': 1,
    'BLOCK_RESTORE': 2,
    'DELETE_RECORD': 3,
    'REDACT_RECORD': 4,
    'ANONYMIZE_RECORD': 5,
    'VERIFY_RECORD_ABSENT': 1,
    'VERIFY_RECORD_PRESENT': 2,
    'VERIFY_RECORD_REDACTED': 3,
    'VERIFY_RECORD_ANONYMIZED': 4,
    'VERIFY_DATA_FLOW_DISABLED': 5,
    'VERIFY_RESTORE_BLOCKED': 6,
}

def sort_steps(steps):
    def sort_key(s):
        return (
            PHASE_ORDER.get(s['phase'], 99),
            OP_ORDER.get(s['operation'], 99),
            s['system_id'],
            s['resource_id']
        )
    sorted_steps = sorted(steps, key=sort_key)
    for idx, s in enumerate(sorted_steps, 1):
        s['step_no'] = idx
    return sorted_steps

with open('dataset/sample_output.csv', 'r', encoding='utf-8') as f:
    sample_outputs = {r['case_id']: r for r in csv.DictReader(f)}

with open('dataset/sample_deletion_requests.csv', 'r', encoding='utf-8') as f:
    sample_requests = list(csv.DictReader(f))

# Helper to find account_id for user if not in obs
user_account_map = {}
with open('dataset/system_activity.csv', 'r', encoding='utf-8') as f:
    for r in csv.DictReader(f):
        res = r['resource_id']
        if res.startswith('account_'):
            for uid, emails in loader.uid_to_emails.items():
                if uid in r['details'] or any(e in r['details'] for e in emails):
                    user_account_map[uid] = res

# Compare steps
perfect_step_matches = 0

for req in sample_requests:
    cid = req['case_id']
    email = req['email'].lower()
    audit_at = req['audit_at']
    uid = loader.resolve_uid(email)
    gold = sample_outputs[cid]
    gold_status = gold['deletion_status']
    gold_steps = json.loads(gold['steps_json'])
    
    # Get all observations <= audit_at
    obs_list = [o for o in loader.user_observations.get(uid, []) if o['captured_at'] <= audit_at]
    
    # Check violations
    violations = []
    compliant_obs = []
    for o in obs_list:
        is_viol = False
        if o['system_id'] == 'account_service' and o['state'] == 'PRESENT':
            is_viol = True
        elif o['system_id'] == 'search_service' and o['state'] == 'PRESENT':
            is_viol = True
        elif o['system_id'] == 'export_service' and o['state'] == 'PRESENT':
            is_viol = True
        elif o['system_id'] == 'backup_service' and o['state'] == 'ACTIVE':
            is_viol = True
        elif o['system_id'] == 'integration_service' and o['state'] == 'ACTIVE':
            is_viol = True
        elif o['system_id'] == 'support_platform' and o['state'] == 'PRESENT':
            is_viol = True
        elif o['system_id'] == 'analytics_platform' and o['state'] == 'PRESENT':
            is_viol = True
        elif o['is_pii_exposed']:
            is_viol = True
        
        if is_viol:
            violations.append(o)
        else:
            compliant_obs.append(o)
            
    # De-duplicate violations by (system_id, resource_id)
    unique_violations = {}
    for v in violations:
        unique_violations[(v['system_id'], v['resource_id'])] = v
    violations = list(unique_violations.values())
    
    steps = []
    if violations:
        status = 'INCOMPLETE'
        # 1. Findings
        for v in violations:
            sys_id = v['system_id']
            res_id = v['resource_id']
            if sys_id == 'backup_service':
                op = 'REPORT_RESTORE_RISK'
                st = 'ACTIVE'
            elif sys_id == 'integration_service':
                op = 'REPORT_ACTIVE_DATA_FLOW'
                st = 'ACTIVE'
            elif v['is_pii_exposed']:
                op = 'REPORT_EXPOSED_PII'
                st = 'PRESENT'
            else:
                op = 'REPORT_REMAINING_RECORD'
                st = 'PRESENT'
            steps.append({
                'phase': 'FINDING',
                'system_id': sys_id,
                'resource_id': res_id,
                'operation': op,
                'state': st,
                'evidence_id': v['evidence_id']
            })
            
        # 2. Remediation
        for v in violations:
            sys_id = v['system_id']
            res_id = v['resource_id']
            if sys_id == 'backup_service':
                op = 'BLOCK_RESTORE'
                st = 'BLOCKED'
            elif sys_id == 'integration_service':
                op = 'DISABLE_DATA_FLOW'
                st = 'DISABLED'
            elif sys_id == 'analytics_platform' and v['is_pii_exposed']:
                op = 'ANONYMIZE_RECORD'
                st = 'ANONYMIZED'
            elif (sys_id in ['support_platform', 'identity_service']) and v['is_pii_exposed']:
                op = 'REDACT_RECORD'
                st = 'REDACTED'
            else:
                op = 'DELETE_RECORD'
                st = 'ABSENT'
            steps.append({
                'phase': 'REMEDIATION',
                'system_id': sys_id,
                'resource_id': res_id,
                'operation': op,
                'state': st,
                'evidence_id': ''
            })

        # 3. Post-remediation verification
        # 3a. For remediated resources
        for v in violations:
            sys_id = v['system_id']
            res_id = v['resource_id']
            if sys_id == 'backup_service':
                op = 'VERIFY_RESTORE_BLOCKED'
                st = 'BLOCKED'
            elif sys_id == 'integration_service':
                op = 'VERIFY_DATA_FLOW_DISABLED'
                st = 'DISABLED'
            elif sys_id == 'analytics_platform' and v['is_pii_exposed']:
                op = 'VERIFY_RECORD_ANONYMIZED'
                st = 'ANONYMIZED'
            elif (sys_id in ['support_platform', 'identity_service']) and v['is_pii_exposed']:
                op = 'VERIFY_RECORD_REDACTED'
                st = 'REDACTED'
            else:
                op = 'VERIFY_RECORD_ABSENT'
                st = 'ABSENT'
            steps.append({
                'phase': 'VERIFICATION',
                'system_id': sys_id,
                'resource_id': res_id,
                'operation': op,
                'state': st,
                'evidence_id': ''
            })
            
        # 3b. For compliant resources that already passed
        for c in compliant_obs:
            sys_id = c['system_id']
            res_id = c['resource_id']
            # Avoid duplicate if already verified
            if any(s['system_id'] == sys_id and s['resource_id'] == res_id for s in steps if s['phase'] == 'VERIFICATION'):
                continue
            if sys_id == 'account_service':
                op = 'VERIFY_RECORD_ABSENT'
                st = 'ABSENT'
            elif sys_id in ['security_service', 'legal_retention_service']:
                op = 'VERIFY_RECORD_PRESENT'
                st = 'PRESENT'
            elif sys_id == 'identity_service':
                op = 'VERIFY_RECORD_REDACTED'
                st = 'REDACTED'
            elif sys_id == 'analytics_platform':
                op = 'VERIFY_RECORD_ANONYMIZED'
                st = 'ANONYMIZED'
            elif sys_id == 'support_platform':
                op = 'VERIFY_RECORD_REDACTED'
                st = 'REDACTED'
            elif sys_id == 'integration_service':
                op = 'VERIFY_DATA_FLOW_DISABLED'
                st = 'DISABLED'
            elif sys_id == 'backup_service':
                op = 'VERIFY_RESTORE_BLOCKED'
                st = 'BLOCKED'
            else:
                continue
            steps.append({
                'phase': 'VERIFICATION',
                'system_id': sys_id,
                'resource_id': res_id,
                'operation': op,
                'state': st,
                'evidence_id': ''
            })
    else:
        status = 'COMPLETE'
        for c in compliant_obs:
            sys_id = c['system_id']
            res_id = c['resource_id']
            if any(s['system_id'] == sys_id and s['resource_id'] == res_id for s in steps):
                continue
            if sys_id == 'account_service':
                op = 'VERIFY_RECORD_ABSENT'
                st = 'ABSENT'
            elif sys_id in ['security_service', 'legal_retention_service']:
                op = 'VERIFY_RECORD_PRESENT'
                st = 'PRESENT'
            elif sys_id == 'identity_service':
                op = 'VERIFY_RECORD_REDACTED'
                st = 'REDACTED'
            elif sys_id == 'analytics_platform':
                op = 'VERIFY_RECORD_ANONYMIZED'
                st = 'ANONYMIZED'
            elif sys_id == 'support_platform':
                op = 'VERIFY_RECORD_REDACTED'
                st = 'REDACTED'
            elif sys_id == 'integration_service':
                op = 'VERIFY_DATA_FLOW_DISABLED'
                st = 'DISABLED'
            elif sys_id == 'backup_service':
                op = 'VERIFY_RESTORE_BLOCKED'
                st = 'BLOCKED'
            else:
                continue
            steps.append({
                'phase': 'VERIFICATION',
                'system_id': sys_id,
                'resource_id': res_id,
                'operation': op,
                'state': st,
                'evidence_id': c['evidence_id']
            })

    sorted_steps = sort_steps(steps)
    
    # Compare against gold steps
    gold_tuples = [(s['phase'], s['system_id'], s['resource_id'], s['operation'], s['state']) for s in gold_steps]
    pred_tuples = [(s['phase'], s['system_id'], s['resource_id'], s['operation'], s['state']) for s in sorted_steps]
    
    step_match = (gold_tuples == pred_tuples)
    if step_match:
        perfect_step_matches += 1
    
    print(f"[{cid}] Steps count: pred={len(sorted_steps)}, gold={len(gold_steps)} | Match: {step_match}")
    if not step_match and len(gold_steps) < 5:
        print(f"   Gold: {gold_tuples}")
        print(f"   Pred: {pred_tuples}")

print(f"\nExact step match: {perfect_step_matches}/32 ({perfect_step_matches/32*100:.1f}%)")
