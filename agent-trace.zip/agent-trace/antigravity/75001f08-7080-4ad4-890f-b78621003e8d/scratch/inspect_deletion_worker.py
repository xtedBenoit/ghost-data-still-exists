import csv
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/system_activity.csv', 'r', encoding='utf-8') as f:
    acts = [r for r in csv.DictReader(f) if r['source_system'] == 'deletion_worker']

print(f"Total deletion_worker activities: {len(acts)}")

# Group by time proximity or inspect clusters
clusters = []
curr_cluster = []
for a in acts:
    if not curr_cluster:
        curr_cluster.append(a)
    else:
        # If within 1 hour of previous activity, same batch/cluster?
        # Let's inspect
        curr_cluster.append(a)

for a in acts[:25]:
    print(f"{a['activity_id']} | {a['event_time']} | {a['event_type']} | {a['target_system']} | {a['resource_id']} | {a['reported_result']}")
