import csv
import json

PHASE_ORDER = {"FINDING": 1, "REMEDIATION": 2, "VERIFICATION": 3}

OP_ORDER = {
    # Findings
    "REPORT_REMAINING_RECORD": 1,
    "REPORT_EXPOSED_PII": 2,
    "REPORT_ACTIVE_DATA_FLOW": 3,
    "REPORT_RESTORE_RISK": 4,
    # Remediation
    "DISABLE_DATA_FLOW": 1,
    "BLOCK_RESTORE": 2,
    "DELETE_RECORD": 3,
    "REDACT_RECORD": 4,
    "ANONYMIZE_RECORD": 5,
    # Verification
    "VERIFY_RECORD_ABSENT": 1,
    "VERIFY_RECORD_PRESENT": 2,
    "VERIFY_RECORD_REDACTED": 3,
    "VERIFY_RECORD_ANONYMIZED": 4,
    "VERIFY_DATA_FLOW_DISABLED": 5,
    "VERIFY_RESTORE_BLOCKED": 6,
}

def sort_key(step):
    p_rank = PHASE_ORDER[step["phase"]]
    op_rank = OP_ORDER[step["operation"]]
    sys_id = step["system_id"]
    res_id = step["resource_id"]
    return (p_rank, op_rank, sys_id, res_id)

with open('dataset/sample_output.csv', 'r', encoding='utf-8') as f:
    samples = list(csv.DictReader(f))

all_correct = True
for row in samples:
    cid = row["case_id"]
    steps = json.loads(row["steps_json"])
    # Check step numbering
    for i, s in enumerate(steps, 1):
        if s["step_no"] != i:
            print(f"{cid}: Step numbering issue: expected {i}, got {s['step_no']}")
            all_correct = False
    # Check sort order
    sorted_steps = sorted(steps, key=sort_key)
    for orig, srt in zip(steps, sorted_steps):
        if orig["operation"] != srt["operation"] or orig["system_id"] != srt["system_id"] or orig["resource_id"] != srt["resource_id"]:
            print(f"{cid}: Sort order mismatch!")
            print("Original:", [(s["phase"], s["operation"], s["system_id"], s["resource_id"]) for s in steps])
            print("Expected:", [(s["phase"], s["operation"], s["system_id"], s["resource_id"]) for s in sorted_steps])
            all_correct = False
            break

if all_correct:
    print("ALL 32 SAMPLE OUTPUTS PERFECTLY MATCH THE EXACT SORTING SPECIFICATION!")
