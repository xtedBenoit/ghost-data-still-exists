import sys
sys.stdout.reconfigure(encoding='utf-8')

import csv

# Check system_activity.csv for resources in sample cases
with open('dataset/system_activity.csv', 'r', encoding='utf-8') as f:
    activities = list(csv.DictReader(f))

resources_in_act = {a['resource_id']: a for a in activities}

sample_resources = [
    "account_001", "account_002", "account_7566", "audit_record_2016", "analytics_9406",
    "search_001", "support_001", "backup_4978", "data_flow_9522"
]

print("Resource presence in system_activity.csv:")
for r in sample_resources:
    if r in resources_in_act:
        act = resources_in_act[r]
        print(f"  FOUND {r}: type={act['event_type']}, src={act['source_system']}, tgt={act['target_system']}, res={act['reported_result']}, details={act['details']}")
    else:
        print(f"  NOT FOUND: {r}")
