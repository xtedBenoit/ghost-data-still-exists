import csv
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/system_activity.csv', 'r', encoding='utf-8') as f:
    for r in csv.DictReader(f):
        if 'account_3960' in str(r) or 'audit_record_4902' in str(r):
            print(r)
