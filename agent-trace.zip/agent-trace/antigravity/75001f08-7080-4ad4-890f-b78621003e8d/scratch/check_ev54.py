import sqlite3
import sys

sys.stdout.reconfigure(encoding='utf-8')

con = sqlite3.connect(':memory:')
with open('dataset/evidence/databases/customer_accounts_failover_replica_20260902.sql', 'r', encoding='utf-8') as f:
    con.executescript(f.read())

accs = ('account_001', 'account_002', 'account_004', 'account_005')
print('primary:', con.execute('SELECT resource_id, user_id, email, account_status FROM customer_profiles_primary WHERE resource_id IN (?, ?, ?, ?)', accs).fetchall())
print('failover:', con.execute('SELECT resource_id, user_id, email, account_status FROM customer_profiles_failover_replica WHERE resource_id IN (?, ?, ?, ?)', accs).fetchall())
