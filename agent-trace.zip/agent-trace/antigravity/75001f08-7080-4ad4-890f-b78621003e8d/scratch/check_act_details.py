import csv
with open('dataset/system_activity.csv', 'r', encoding='utf-8') as f:
    for row in csv.DictReader(f):
        if row['resource_id'] == 'analytics_9406':
            print("system_activity for analytics_9406:", row)
        if row['resource_id'] == 'account_7566':
            print("system_activity for account_7566:", row)
        if row['resource_id'] == 'audit_record_2016':
            print("system_activity for audit_record_2016:", row)
