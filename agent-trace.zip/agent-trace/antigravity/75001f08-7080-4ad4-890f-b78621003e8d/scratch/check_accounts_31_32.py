import csv

with open('dataset/system_activity.csv', 'r', encoding='utf-8') as f:
    for row in csv.DictReader(f):
        if '4857' in row['resource_id'] or '8858' in row['resource_id']:
            print("system_activity:", row)
