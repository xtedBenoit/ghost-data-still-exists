import sys
sys.stdout.reconfigure(encoding='utf-8')

import os
import glob

search_terms = ["audit_record_2016", "support_001", "account_001", "account_7566", "amina.elmasri@gmail.com", "l.fontaine46@yahoo.com"]

evidence_dir = "dataset/evidence"

for root, dirs, files in os.walk(evidence_dir):
    for f in files:
        fpath = os.path.join(root, f)
        # Check text/sql/json/log
        if fpath.endswith(('.txt', '.sql', '.json', '.log')):
            try:
                with open(fpath, 'r', encoding='utf-8', errors='ignore') as fp:
                    content = fp.read()
                    for term in search_terms:
                        if term in content:
                            print(f"Term '{term}' found in {fpath}")
            except Exception as e:
                pass
