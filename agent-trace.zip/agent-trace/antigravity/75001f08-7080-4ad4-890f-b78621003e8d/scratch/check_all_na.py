import sys
sys.stdout.reconfigure(encoding='utf-8')

import csv

with open('dataset/deletion_requests.csv', 'r', encoding='utf-8') as f:
    requests = list(csv.DictReader(f))

# Let's inspect cases that might NOT be deletion requests
non_deletion_words = [
    'do not close', 'not asking for deletion', 'keep the account', 'not a request to erase',
    "don't delete", 'continue using', 'leave the account', 'in place', 'marketing lists only',
    'resetting the login', 'correct it without removing'
]

found = []
for r in requests:
    text = r['request_text'].lower()
    if any(w in text for w in non_deletion_words):
        found.append(r['case_id'])

print("Cases with non-deletion phrases:", found)
