import sys
sys.stdout.reconfigure(encoding='utf-8')

import csv

with open('dataset/evidence_files.csv', 'r', encoding='utf-8') as f:
    files = list(csv.DictReader(f))

# Group files by origin
origins = {}
for f in files:
    origins.setdefault(f['origin'], []).append(f)

print(f"Total files: {len(files)}, Unique origins: {len(origins)}")
for orig, flist in sorted(origins.items(), key=lambda x: -len(x[1])):
    print(f"\nOrigin: {orig} ({len(flist)} files)")
    for f in flist[:3]:
        print(f"  {f['file_id']}: {f['file_path']} ({f['captured_at']})")
    if len(flist) > 3:
        print(f"  ... and {len(flist) - 3} more")
