import sys
sys.stdout.reconfigure(encoding='utf-8')

import os
import json
import csv
from pathlib import Path

with open('dataset/evidence_files.csv', 'r', encoding='utf-8') as f:
    files = [r for r in csv.DictReader(f) if r['file_path'].endswith('.json')]

print(f"Total JSON files: {len(files)}")
top_keys = {}
for f in files:
    fpath = os.path.join('dataset', f['file_path'])
    try:
        with open(fpath, 'r', encoding='utf-8') as jf:
            data = json.load(jf)
            if isinstance(data, dict):
                k = tuple(sorted(data.keys()))
                top_keys.setdefault(k, []).append((f['file_id'], f['origin'], f['file_path']))
            elif isinstance(data, list):
                top_keys.setdefault(("LIST",), []).append((f['file_id'], f['origin'], f['file_path']))
    except Exception as e:
        print("Error reading", fpath, e)

for keys, flist in top_keys.items():
    print(f"\nKeys: {keys} ({len(flist)} files):")
    for fid, orig, p in flist[:3]:
        print(f"  {fid} | {orig} | {p}")
    if len(flist) > 3:
        print(f"  ... and {len(flist) - 3} more")
