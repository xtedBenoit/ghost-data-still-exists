import csv
import json
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/sample_output.csv', 'r', encoding='utf-8') as f:
    sample_outputs = {r['case_id']: r for r in csv.DictReader(f)}

with open('dataset/sample_deletion_requests.csv', 'r', encoding='utf-8') as f:
    sample_requests = {r['case_id']: r for r in csv.DictReader(f)}

missed = ['case_08', 'case_10', 'case_12', 'case_17', 'case_19']

for cid in missed:
    gold = sample_outputs[cid]
    req = sample_requests[cid]
    print(f"\n=== {cid} ===")
    print(f"Email: {req['email']}, audit_at: {req['audit_at']}")
    print(f"Gold status: {gold['deletion_status']}")
    print(f"Gold steps:")
    for s in json.loads(gold['steps_json']):
        print(f"  {s['phase']} | {s['system_id']} | {s['resource_id']} | {s['operation']} | {s['state']} | ev: {s['evidence_id']}")
