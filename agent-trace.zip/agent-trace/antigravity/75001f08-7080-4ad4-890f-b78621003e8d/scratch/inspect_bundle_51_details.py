import json
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/evidence/records/customer_data_snapshot_bundle_20260915.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

for s in data['snapshots']:
    print(f"data_store: {s.get('data_store')}, collection: {s.get('collection')}, records count: {len(s.get('records', []))}")
    if s.get('records'):
        print("  sample record:", s['records'][0])
