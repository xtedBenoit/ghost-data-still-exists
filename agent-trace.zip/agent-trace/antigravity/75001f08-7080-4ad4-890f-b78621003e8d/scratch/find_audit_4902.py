import os

for root, dirs, files in os.walk('dataset'):
    for f in files:
        if f.endswith(('.csv', '.json', '.sql', '.log', '.txt')):
            path = os.path.join(root, f)
            try:
                with open(path, 'r', encoding='utf-8', errors='ignore') as fp:
                    content = fp.read()
                    if 'audit_record_4902' in content:
                        print("Found audit_record_4902 in:", path)
            except Exception:
                pass
