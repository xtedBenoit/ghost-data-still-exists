import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/evidence/logs/structured_service_events_eu_west_20260918.log', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for idx, line in enumerate(lines):
    if 'audit_record_4902' in line or 'account_3960' in line:
        print(f"--- line {idx} ---")
        for j in range(max(0, idx - 3), min(len(lines), idx + 4)):
            print(f"{j}: {lines[j].strip()}")
