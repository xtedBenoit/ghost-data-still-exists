import re
import zlib

with open("dataset/evidence/documents/account_history_report_20260718.pdf", 'rb') as f:
    data = f.read()

# Pattern for PDF objects: N M obj ... endobj
obj_pattern = re.compile(rb'(\d+)\s+(\d+)\s+obj\s*(.*?)\s*endobj', re.DOTALL)
for m in obj_pattern.finditer(data):
    obj_id = m.group(1).decode()
    body = m.group(3)
    if b'stream' in body:
        stream_m = re.search(rb'<<(.*?)>>\s*stream[\r\n]+(.*?)[\r\n]+endstream', body, re.DOTALL)
        if stream_m:
            dict_part = stream_m.group(1)
            stream_bytes = stream_m.group(2)
            try:
                decomp = zlib.decompress(stream_bytes)
                print(f"Obj {obj_id} dict: {dict_part.decode('latin1')}")
                print(f"  Decompressed: {len(decomp)} bytes")
                # Look for printable strings
                # In PDF, text strings can be in Tj or hex strings <...>
                print("  Sample text:", repr(decomp[:200].decode('latin1', errors='ignore')))
            except Exception as e:
                pass
