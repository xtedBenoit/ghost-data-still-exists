import json
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/evidence/records/customer_data_snapshot_bundle_20260322.json', 'r', encoding='utf-8') as f:
    bundle = json.load(f)

for snap in bundle.get('snapshots', []):
    for r in snap.get('records', []):
        if 'user_43' in str(r) or 'fontaine' in str(r):
            print(f"data_store={snap.get('data_store')}, coll={snap.get('collection')}: {r}")
