import sys
sys.stdout.reconfigure(encoding='utf-8')

import csv

with open('dataset/system_activity.csv', 'r', encoding='utf-8') as f:
    activities = list(csv.DictReader(f))

# Look at details and see what fields exist
print(f"Total system activities: {len(activities)}")

import re
# Check how user references appear in details
sample_details = [a['details'] for a in activities[:30]]
for d in sample_details[:10]:
    print("Detail:", d)
