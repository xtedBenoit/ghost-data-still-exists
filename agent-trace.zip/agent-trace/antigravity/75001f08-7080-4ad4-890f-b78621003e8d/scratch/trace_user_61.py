import csv
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/system_activity.csv', 'r', encoding='utf-8') as f:
    for r in csv.DictReader(f):
        if 'user_61' in str(r) or 'k.appiah88@gmail.com' in str(r):
            print("system_activity user_61:", r)
