import csv
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/deletion_requests.csv', 'r', encoding='utf-8') as f:
    requests = list(csv.DictReader(f))

explicit_not_delete = [
    "leave the account active",
    "not asking for deletion",
    "keep the account as it is",
    "do not close the account",
    "without removing any of my records",
    "marketing lists only",
    "not a request to erase",
    "leave my profile",
    "continue using the service",
    "don't delete",
    "dont delete",
    "not a deletion",
    "do not delete",
    "keep my account",
    "leave the account open"
]

detected = []
for r in requests:
    text = r['request_text'].lower()
    for phrase in explicit_not_delete:
        if phrase in text:
            detected.append((r['case_id'], phrase, r['request_text']))
            break

print(f"Total detected: {len(detected)}")
for cid, phrase, txt in detected:
    print(f"  {cid} [{phrase}]: {txt}")
