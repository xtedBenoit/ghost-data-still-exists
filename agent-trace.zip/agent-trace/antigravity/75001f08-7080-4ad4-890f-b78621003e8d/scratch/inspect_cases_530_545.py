import csv
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/deletion_requests.csv', 'r', encoding='utf-8') as f:
    for r in csv.DictReader(f):
        if r['case_id'] in [f'case_{i}' for i in range(530, 545)]:
            print(f"{r['case_id']}: {r['request_text']}")
