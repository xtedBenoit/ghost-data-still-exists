import sqlite3
import sys

sys.stdout.reconfigure(encoding='utf-8')

con = sqlite3.connect(':memory:')
with open('dataset/evidence/databases/customer_data_inventory_20260916.sql', 'r', encoding='utf-8') as f:
    con.executescript(f.read())

print("Tables in evidence_93:")
tables = [t[0] for t in con.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
for t in tables:
    cols = [c[1] for c in con.execute(f"PRAGMA table_info({t})").fetchall()]
    # Search all text cols for k.appiah88@gmail.com or user_61
    where_clauses = [f"{c} LIKE '%appiah%' OR {c} LIKE '%user_61%'" for c in cols]
    if where_clauses:
        query = f"SELECT * FROM {t} WHERE " + " OR ".join(where_clauses)
        try:
            matches = con.execute(query).fetchall()
            if matches:
                print(f"Table {t} matches:", matches)
        except Exception as e:
            pass
