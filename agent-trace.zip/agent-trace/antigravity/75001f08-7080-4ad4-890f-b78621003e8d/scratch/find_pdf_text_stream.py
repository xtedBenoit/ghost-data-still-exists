with open("dataset/evidence/documents/account_history_report_20260718.pdf", 'rb') as f:
    data = f.read()

import re
matches = [m.start() for m in re.finditer(b'stream', data)]
for off in matches:
    end = data.find(b'endstream', off)
    content = data[off+len(b'stream'):end].strip()
    import zlib
    try:
        decomp = zlib.decompress(content)
        if b'BT' in decomp: # Text block in PDF!
            print(f"Found text stream at {off} ({len(decomp)} bytes):")
            # print all printable strings
            print(decomp.decode('latin1', errors='ignore'))
    except Exception as e:
        pass
