import csv
import json
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/sample_output.csv', 'r', encoding='utf-8') as f:
    sample_outputs = list(csv.DictReader(f))

with open('dataset/sample_deletion_requests.csv', 'r', encoding='utf-8') as f:
    sample_requests = {r['case_id']: r for r in csv.DictReader(f)}

print(f"Loaded {len(sample_outputs)} sample outputs.")

statuses = {}
for row in sample_outputs:
    status = row['deletion_status']
    statuses[status] = statuses.get(status, 0) + 1
print("Statuses count:", statuses)

# Check all operations in steps_json
ops_by_phase = {}
for row in sample_outputs:
    steps = json.loads(row['steps_json'])
    for s in steps:
        phase = s['phase']
        op = s['operation']
        state = s['state']
        ops_by_phase.setdefault(phase, set()).add((op, state))

print("\nOperations by Phase and State:")
for phase, ops in ops_by_phase.items():
    print(f"Phase {phase}:")
    for op, state in sorted(ops):
        print(f"  operation={op}, state={state}")
