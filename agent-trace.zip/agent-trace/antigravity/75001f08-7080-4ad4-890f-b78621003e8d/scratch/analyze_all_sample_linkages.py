import csv
import json
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/sample_output.csv', 'r', encoding='utf-8') as f:
    sample_outputs = list(csv.DictReader(f))

with open('dataset/sample_deletion_requests.csv', 'r', encoding='utf-8') as f:
    sample_requests = {r['case_id']: r for r in csv.DictReader(f)}

with open('dataset/user_identities.csv', 'r', encoding='utf-8') as f:
    user_identities = {r['email'].lower(): r for r in csv.DictReader(f)}

print("=== All 32 Sample Cases Linkage Analysis ===")
for row in sample_outputs:
    cid = row['case_id']
    req = sample_requests[cid]
    status = row['deletion_status']
    steps = json.loads(row['steps_json'])
    u = user_identities.get(req['email'].lower(), {})
    uid = u.get('user_id', 'unknown')
    
    findings = [s for s in steps if s['phase'] == 'FINDING']
    verifs = [s for s in steps if s['phase'] == 'VERIFICATION']
    
    ev_ids = sorted(list(set(s['evidence_id'] for s in steps if s['evidence_id'])))
    
    print(f"\n[{cid}] Status={status} | User={uid} | Email={req['email']} | AuditAt={req['audit_at']}")
    print(f"  Evidence cited: {', '.join(ev_ids)}")
    if findings:
        print(f"  Findings ({len(findings)}):")
        for f in findings:
            print(f"    - {f['system_id']} | {f['resource_id']} | {f['operation']} | ev: {f['evidence_id']}")
    print(f"  Verifications ({len(verifs)}):")
    for v in verifs:
        print(f"    - {v['system_id']} | {v['resource_id']} | {v['operation']} | {v['state']} | ev: '{v['evidence_id']}'")
