import csv
import json
import sqlite3
import os
import glob
import re

# 1. Load identities
user_to_emails = {}
email_to_user = {}

with open('dataset/user_identities.csv', 'r', encoding='utf-8') as f:
    for r in csv.DictReader(f):
        u = r['user_id']
        e = r['email'].lower()
        user_to_emails.setdefault(u, set()).add(e)
        email_to_user[e] = u

with open('dataset/user_audit_log.csv', 'r', encoding='utf-8') as f:
    for r in csv.DictReader(f):
        u = r['user_id']
        if r['field_name'] == 'email':
            for e_val in [r['old_value'], r['new_value']]:
                if e_val:
                    e = e_val.lower()
                    user_to_emails.setdefault(u, set()).add(e)
                    email_to_user[e] = u

# 2. Map resource_ids from system_activity.csv
resource_to_user = {}
user_to_resources = {}

with open('dataset/system_activity.csv', 'r', encoding='utf-8') as f:
    for r in csv.DictReader(f):
        res = r['resource_id']
        details = r['details']
        # search for user_XX or email in details
        found_u = None
        for u in user_to_emails.keys():
            if u in details or u in res:
                found_u = u
                break
        if not found_u:
            for e, u in email_to_user.items():
                if e in details:
                    found_u = u
                    break
        if found_u:
            resource_to_user[res] = found_u
            user_to_resources.setdefault(found_u, set()).add(res)

print(f"Mapped {len(resource_to_user)} resources from system_activity.csv to users.")

# 3. Check sample cases resources coverage
with open('dataset/sample_output.csv', 'r', encoding='utf-8') as f:
    sample_outputs = list(csv.DictReader(f))

with open('dataset/sample_deletion_requests.csv', 'r', encoding='utf-8') as f:
    sample_requests = {r['case_id']: r for r in csv.DictReader(f)}

all_sample_resources = set()
for s in sample_outputs:
    steps = json.loads(s['steps_json'])
    for step in steps:
        all_sample_resources.add((s['case_id'], step['system_id'], step['resource_id']))

print(f"Total (case, system, resource) in sample outputs: {len(all_sample_resources)}")
