import csv
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/evidence_files.csv', 'r', encoding='utf-8') as f:
    for row in csv.DictReader(f):
        if row['file_path'].endswith('.json'):
            print(f"{row['file_id']} | {row['origin']} | {row['file_path']}")
