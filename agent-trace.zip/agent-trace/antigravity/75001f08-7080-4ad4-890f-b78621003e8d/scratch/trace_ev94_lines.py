import re
import json

lines = [
    '2026-09-26T07:57:13Z level=DEBUG service=search_service trace_id=rb-075713-004 event=index_query_started resource_id=search_4262 lookup_key=akosua.gyasi@gmail.com',
    '2026-09-26T07:57:13Z level=INFO service=search_service trace_id=rb-075713-004 event=index_query_completed resource_id=search_4262 result=hit total_hits=1 index=customer_directory_v3 email=akosua.gyasi@gmail.com customer_reference=null',
    '2026-09-26T07:59:44Z level=DEBUG service=support_platform trace_id=rb-075944-005 event=support_ticket_read_started resource_id=support_5569 lookup_key=mori.ren@gmail.com',
    '2026-09-26T07:59:44Z level=INFO service=support_platform trace_id=rb-075944-005 event=support_ticket_read_completed resource_id=support_5569 customer_reference=null requester_name=null requester_email=mori.ren@gmail.com requester_phone=null'
]

traces = {}
for line_str in lines:
    matches = re.findall(r'(\w+)=(?:"([^"]*)"|([^\s]+))', line_str)
    kv = {m[0]: m[1] if m[1] else m[2] for m in matches}
    tr = kv.get('trace_id')
    res = kv.get('resource_id')
    svc = kv.get('service')
    ev = kv.get('event', '')
    ident = None
    for k in ['lookup_key', 'subject_key', 'match_key', 'correlation_key', 'subject_reference', 'customer_reference', 'user_id', 'email', 'requester_email', 'matched_value']:
        val = kv.get(k)
        if val and val not in ['null', 'None', '']:
            ident = val
            break
    if tr and ident:
        traces.setdefault(tr, {})['ident'] = ident
    if tr and res:
        traces.setdefault(tr, {})['res'] = res
    if tr and svc:
        traces.setdefault(tr, {})['svc'] = svc

    u_ident = ident or (traces.get(tr, {}).get('ident') if tr else None)
    res_id = res or (traces.get(tr, {}).get('res') if tr else None)
    print("Parsed line:", tr, u_ident, res_id, "kv:", kv)
