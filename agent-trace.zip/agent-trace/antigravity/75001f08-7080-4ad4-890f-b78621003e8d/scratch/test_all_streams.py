with open("dataset/evidence/documents/account_history_report_20260718.pdf", 'rb') as f:
    data = f.read()

import re
matches = [m.start() for m in re.finditer(b'stream', data)]
for off in matches:
    end = data.find(b'endstream', off)
    content_start = off + len(b'stream')
    while data[content_start:content_start+1] in b'\r\n':
        content_start += 1
    content_end = end
    while data[content_end-1:content_end] in b'\r\n':
        content_end -= 1
    content = data[content_start:content_end]
    import zlib
    try:
        decomp = zlib.decompress(content)
        print(f"Decompressed stream at {off}: len={len(decomp)}")
        sample = decomp[:120].decode('latin1', errors='ignore')
        print("  Sample:", repr(sample))
    except Exception as e:
        print(f"Failed stream at {off}:", e)
