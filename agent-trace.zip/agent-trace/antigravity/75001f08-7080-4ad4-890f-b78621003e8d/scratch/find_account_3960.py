import os
import glob
import sys

sys.stdout.reconfigure(encoding='utf-8')

for root, dirs, files in os.walk('dataset'):
    for f in files:
        if f.endswith(('.sql', '.json', '.log', '.csv', '.txt')):
            p = os.path.join(root, f)
            try:
                with open(p, 'r', encoding='utf-8', errors='ignore') as fp:
                    content = fp.read()
                    if 'account_3960' in content or 'audit_record_4902' in content:
                        print(f"Found in {p}")
            except Exception as e:
                pass
