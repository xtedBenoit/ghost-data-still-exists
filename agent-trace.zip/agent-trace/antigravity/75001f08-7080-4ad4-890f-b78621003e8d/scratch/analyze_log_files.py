import sys
sys.stdout.reconfigure(encoding='utf-8')

import os
import csv
from pathlib import Path

with open('dataset/evidence_files.csv', 'r', encoding='utf-8') as f:
    files = [r for r in csv.DictReader(f) if r['file_path'].endswith('.log')]

print(f"Total LOG files: {len(files)}")
origins = {}
for f in files:
    origins.setdefault(f['origin'], []).append((f['file_id'], f['file_path']))

for orig, flist in origins.items():
    print(f"\nOrigin: {orig} ({len(flist)} files):")
    for fid, p in flist[:3]:
        print(f"  {fid} | {p}")
    if len(flist) > 3:
        print(f"  ... and {len(flist) - 3} more")

# Read sample lines from each origin
for orig, flist in origins.items():
    sample_file = os.path.join('dataset', flist[0][1])
    print(f"\n--- Sample from {orig} ({flist[0][0]}): ---")
    with open(sample_file, 'r', encoding='utf-8') as lf:
        for _ in range(3):
            line = lf.readline()
            if line:
                print("  ", line.strip())
