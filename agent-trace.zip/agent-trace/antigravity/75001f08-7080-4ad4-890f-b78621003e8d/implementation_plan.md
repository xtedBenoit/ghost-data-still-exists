# Plan d'Implémentation : Agent d'Audit de Suppression de Données ("Ghost Data Still Exists")

Ce document détaille l'architecture, la méthodologie et les étapes de réalisation du système d'audit de suppression automatisé pour le défi **HackerRank Orchestrate — Ghost Data Still Exists**.

---

## 1. Description des Objectifs & Périmètre

Northstar Shop a subi une perte financière et réputationnelle majeure après qu'un compte client supposé supprimé soit réapparu dans ses systèmes en tant que "donnée fantôme" (ghost data). Bien que le tableau de bord interne indiquait un statut "Complete", des données personnelles subsistaient dans les répliques secondaires, pièces jointes de support, index de recherche, exports, sauvegardes et flux de synchronisation actifs.

L'objectif est de concevoir et déployer un **agent d'audit de suppression IA** capable de :
1. Déterminer avec certitude si une requête autorise la suppression (`COMPLETE`, `INCOMPLETE`, ou `NOT_APPLICABLE`).
2. Résoudre les identités actuelles et historiques des utilisateurs à travers les logs d'audit.
3. Examiner l'état réel des données à la date d'audit (`audit_at`) à travers l'ensemble des preuves multimodales (bases SQLite/SQL, fichiers JSON, journaux d'observabilité, captures d'écran, documents PDF).
4. Détecter les enregistrements résiduels, fuites de PII, flux de données actifs (`data_flow`) et risques de restauration (`backup_restore`).
5. Générer la liste ordonnée et déterministe des constatations (`FINDING`), des mesures de remédiation (`REMEDIATION`), et des vérifications (`VERIFICATION`) selon la politique stricte de `deletion_rules.csv`.
6. Produire un fichier `output.csv` de 518 lignes respectant strictement le schéma requis, accompagné des rapports d'évaluation et d'usage de tokens (`evaluation_report.md`, `usage_report.md`), et du journal d'audit `log.txt`.

```mermaid
flowchart TD
    DR[deletion_requests.csv\n518 cas] --> IntentClassifier[Classificateur d'Intention\nSuppression vs Non-Suppression]
    
    IntentClassifier -->|Non-suppression\naccès, opt-out, modif| NA[NOT_APPLICABLE\nsteps_json = empty]
    
    IntentClassifier -->|Demande de suppression\nvalide| IdentityResolver[Résolveur d'Identités\nuser_identities.csv + user_audit_log.csv]
    
    IdentityResolver --> Identifiers[Identifiants Résolus\nuser_id, emails, tels, noms, hash]
    
    Identifiers --> EvidenceEngine[Moteur d'Investigation & Preuves\nSQL, JSON, Logs, Images, PDF\nFiltre: timestamp <= audit_at]
    
    EvidenceEngine --> ResourceStates[États des Ressources\naccount, search, analytics, support,\nexport, backup, integration, security]
    
    ResourceStates --> PolicyEngine[Moteur de Politiques\ndeletion_rules.csv]
    
    PolicyEngine --> StatusBranch{Conformité Totale\nau moment de audit_at ?}
    
    StatusBranch -->|Oui, 0 violation/risque| CompleteGen[Génération COMPLETE\nUniquement VERIFICATION\navec evidence_id validée]
    StatusBranch -->|Non, données résiduelles ou risques| IncompleteGen[Génération INCOMPLETE\n1. FINDING avec evidence_id\n2. REMEDIATION sans evidence_id\n3. VERIFICATION sans evidence_id]
    
    CompleteGen --> CanonicalSorter[Tri Canonique Déterministe\nPhase -> Opération -> System -> Resource]
    IncompleteGen --> CanonicalSorter
    
    CanonicalSorter --> OutputCSV[output.csv\n518 lignes ordonnées]
    OutputCSV --> EvalEngine[Pipeline d'Évaluation\nExactitude, Séquences, 3 Cas Tests]
```

---

## 2. Revue Utilisateur Requise

> [!IMPORTANT]
> - **Livrables Hackerrank** :
>   1. `code.zip` contenant le code exécutable, `README.md`, `code/evaluation/evaluation_report.md` et `code/evaluation/usage_report.md`. (Sans inclure `dataset/`, `.venv`, ou `__pycache__`).
>   2. `output.csv` à la racine du projet (exactement 518 lignes de prédiction, triées par `case_id`).
>   3. `log.txt` à la racine traçant chaque tour selon le protocole `AGENTS.md`.
> - **Contrainte temporelle `audit_at`** :
>   Toute preuve dont `captured_at` ou l'horodatage est postérieur à `audit_at` d'un cas doit impérativement être ignorée pour ce cas. Les statuts déclarés (`reported_status`) et les résultats d'activité (`reported_result`) sont de simples allégations qui ne font pas foi.

---

## 3. Architecture Détaillée des Composants

### A. Résolveur d'Identités (`code/identity_resolver.py`)
- Charge `user_identities.csv` et `user_audit_log.csv`.
- Pour une adresse email fournie dans la requête :
  - Recherche directe par email dans `user_identities.csv` (insensible à la casse).
  - Si absent, recherche dans `user_audit_log.csv` (`old_value` ou `new_value` où `field_name == 'email'`).
- Récupère le `user_id` canonique et l'ensemble des identifiants associés :
  - Emails (actuel + historiques)
  - Téléphones (actuel + historiques)
  - Noms complets (actuel + historiques)
  - Hash SHA-256 de l'email
- Restreint les identifiants historiques à ceux actifs avant ou à `audit_at`.

### B. Classificateur d'Intention de Requête (`code/intent_classifier.py`)
- Détermine si `request_text` constitue une demande effective d'effacement / clôture définitive du compte.
- Détecte les requêtes de non-suppression :
  - Droit d'accès / demande de copie d'informations ("what information you hold", "send me a copy", "information request").
  - Exportation / portabilité de données ("download my account information", "portable format").
  - Rectification / mise à jour ("mobile number is out of date", "misspelled", "change the email").
  - Désabonnement marketing ("marketing lists only", "stop promotional emails").
  - Problème de connexion ("resetting the login", "can't access").
- Pour ces cas : classification immédiate en `NOT_APPLICABLE` avec `steps_json = []`.

### C. Moteur d'Ingestion & Indexation des Preuves (`code/evidence_loader.py`)
Indexation des 94 fichiers de preuves situés dans `dataset/evidence/` via `evidence_files.csv` :
1. **Fichiers SQL (SQLite compatible)** :
   - `customer_data_inventory_*.sql` : tables `customer_profiles`, `customer_search_documents`, `customer_analytics_profiles`, `support_records`, `customer_exports`, `connector_subscriptions`, `backup_restore_entries`, `security_audit_records`.
   - Répliques SQL (`failover_replica`, `read_replica`, `regional_replicas`, `reporting_replica`) pour détecter les dérives de synchronisation (drift de réplication).
2. **Fichiers JSON** :
   - `service_resource_export_*.json` et `customer_data_snapshot_bundle_*.json`.
   - Exports de tickets, manifests d'exports, connecteurs et registres de sécurité.
3. **Fichiers Journaux (Logs)** :
   - `resource_lookup_trace_*.log` et journaux d'observabilité (`central_observability_export`).
   - Analyse des requêtes HTTP 404 (absence de profil), 200 (présence), statuts de connecteurs et checkpoints de sauvegarde.
4. **Documents & Images (PDF / PNG)** :
   - Extraction des textes et métadonnées (rapports d'historique, consoles de gestion, tickets).

### D. Moteur de Politiques de Deletion (`code/policy_engine.py`)
Applique les 15 règles de `deletion_rules.csv` :
- `USER_PROFILE` / `SECONDARY_IDENTIFIER` / `SEARCH_INDEX_ENTRY` / `CACHE_ENTRY` / `USER_EXPORT` / `MARKETING_PROFILE` : **DELETE**.
- `SUPPORT_MESSAGE` : **REDACT** (conservation du contexte partagé, suppression des identifiants directs).
- `SUPPORT_ATTACHMENT` : **DELETE**.
- `ANALYTICS_PROFILE` / `PRODUCT_TELEMETRY` : **ANONYMIZE** (déliage irréversible, PII supprimées).
- `SECURITY_AUDIT_LOG` / `LEGAL_HOLD_RECORD` : **RETAIN** (vérifier la présence légale `VERIFY_RECORD_PRESENT`).
- `BACKUP_ARCHIVE` : **RETAIN** avec blocage impératif de la restauration (`BLOCK_RESTORE`).
- `ACCOUNT_TOMBSTONE` : **REDACT** (seul le `user_id` est autorisé, nom/email/tél/hash doivent être nuls).

### E. Générateur & Ordonnanceur Canonique (`code/steps_generator.py`)
Pour chaque cas :
1. **Évaluation de l'état** :
   - Si au moins un enregistrement non conforme ou un flux/restore actif est détecté : statut `INCOMPLETE`.
   - Si toutes les copies sont conformes et qu'aucun risque n'existe : statut `COMPLETE`.
2. **Construction des étapes** :
   - Pour `INCOMPLETE` :
     - `FINDING` : `REPORT_REMAINING_RECORD`, `REPORT_EXPOSED_PII`, `REPORT_ACTIVE_DATA_FLOW`, `REPORT_RESTORE_RISK` avec l'identifiant de preuve (`file_id`, `activity_id` ou `audit_id`).
     - `REMEDIATION` : `DISABLE_DATA_FLOW`, `BLOCK_RESTORE`, `DELETE_RECORD`, `REDACT_RECORD`, `ANONYMIZE_RECORD` avec `evidence_id = ""`.
     - `VERIFICATION` : `VERIFY_RECORD_ABSENT`, `VERIFY_RECORD_PRESENT`, `VERIFY_RECORD_REDACTED`, `VERIFY_RECORD_ANONYMIZED`, `VERIFY_DATA_FLOW_DISABLED`, `VERIFY_RESTORE_BLOCKED` avec `evidence_id = ""`.
   - Pour `COMPLETE` :
     - Uniquement `VERIFICATION` prouvant l'état conforme au moment de `audit_at`, chacune citant la preuve correspondante.
   - Pour `NOT_APPLICABLE` :
     - Tableau vide `[]`.
3. **Tri Strict & Numérotation** :
   - Tri par phase (FINDING -> REMEDIATION -> VERIFICATION).
   - Tri par ordre officiel d'opération.
   - Tri par `system_id` croissant, puis `resource_id` croissant.
   - Numérotation consécutive `step_no` débutant à `1`.

---

## 4. Pipeline d'Évaluation & Rapports

### A. Évaluation Locale (`code/evaluation/main.py`)
- Comparaison automatique avec `dataset/sample_output.csv` (32 cas de référence).
- Métriques d'exactitude :
  - **Case-level Status Accuracy** (% statuts corrects).
  - **Step-level & Field-level Accuracy** (exactitude des opérations, états, systèmes, ressources et evidence_id).
  - **Sequence Accuracy** (respect rigoureux de l'ordonnancement canonique).
- Ajout de **3 cas de test d'évaluation personnalisés** documentés dans `code/evaluation/evaluation_report.md` :
  - Cas A : Détection de dérive de synchronisation sur réplique de secours (failover drift).
  - Cas B : Requête de portabilité déguisée en suppression (test de robustesse `NOT_APPLICABLE`).
  - Cas C : Tombstone d'identité avec PII résiduelle et sauvegarde active.

### B. Rapport de Consommation de Tokens (`code/evaluation/usage_report.md`)
- Synthèse complète du run final sur les 518 requêtes.
- Nombre d'appels modèles, décompte précis des tokens d'entrée et de sortie, coûts estimés par requête et au total.

---

## 5. Plan de Vérification & Tests

### Tests Automatisés
1. **Validation sur le jeu Sample (32 cas)** :
   ```powershell
   python code/main.py --mode sample
   python code/evaluation/main.py --mode sample
   ```
   *Objectif : 100% de concordance sur les statuts, opérations et ordonnancement.*

2. **Validation des Règles de Soumission sur les 518 cas** :
   ```powershell
   python code/main.py --mode full
   python -c "import csv, json; rows = list(csv.DictReader(open('output.csv'))); assert len(rows) == 518; print('518 rows valid')"
   ```
   *Vérifications :*
   - Exactitude de l'en-tête : `case_id,deletion_status,steps_json`.
   - Ordre alphabétique des `case_id` (case_33 à case_550).
   - Validité syntaxique de chaque `steps_json`.
   - Respect strict des 10 cas `NOT_APPLICABLE` (`steps_json = []`).
   - Aucune `evidence_id` manquante pour les étapes de preuve `COMPLETE` et `FINDING`.
   - `evidence_id == ""` pour toutes les remédiations et vérifications futures d'`INCOMPLETE`.

3. **Packaging et Vérification de `code.zip`** :
   ```powershell
   Compress-Archive -Path README.md, code -DestinationPath code.zip -Force
   ```
   *Vérifier l'absence de `dataset/`, `.venv/` et `__pycache__`.*

4. **Vérification du journal `log.txt`** :
   *Vérifier que chaque interaction contient `tool=antigravity` et `model=gemini-3.8-flash`.*

---

## 6. Prochaines Étapes après Validation
Dès votre approbation de ce plan :
1. Implémenter les modules dans `code/` (`identity_resolver.py`, `evidence_loader.py`, `policy_engine.py`, `intent_classifier.py`, `steps_generator.py`).
2. Assembler le script principal `code/main.py`.
3. Développer le framework d'évaluation `code/evaluation/main.py` et générer les rapports `evaluation_report.md` et `usage_report.md`.
4. Exécuter l'évaluation complète sur les 518 cas et produire le fichier `output.csv`.
5. Valider et empaqueter `code.zip` prêt pour la soumission Hackerrank.
