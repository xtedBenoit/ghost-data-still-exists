import csv
import sys
import os

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/evidence_files.csv', 'r', encoding='utf-8') as f:
    log_files = [r for r in csv.DictReader(f) if r['file_path'].endswith('.log')]

print(f"Total LOG files: {len(log_files)}")
for l in log_files[:5]:
    path = os.path.join('dataset', l['file_path'])
    with open(path, 'r', encoding='utf-8') as f:
        first_lines = [f.readline().strip() for _ in range(5)]
    print(f"\n{l['file_id']} ({l['origin']}):")
    for line in first_lines:
        print("  ", line)
