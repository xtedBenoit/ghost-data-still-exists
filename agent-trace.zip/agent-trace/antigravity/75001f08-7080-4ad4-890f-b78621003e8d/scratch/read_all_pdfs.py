import sys
sys.stdout.reconfigure(encoding='utf-8')

import os
import csv
from pypdf import PdfReader

with open('dataset/evidence_files.csv', 'r', encoding='utf-8') as f:
    pdfs = [r for r in csv.DictReader(f) if r['file_path'].endswith('.pdf')]

for p in pdfs:
    full_path = os.path.join('dataset', p['file_path'])
    reader = PdfReader(full_path)
    text = ""
    for page in reader.pages:
        text += page.extract_text() or ""
    print(f"\n--- {p['file_id']} ({p['origin']}): {p['file_path']} ---")
    print(f"Pages: {len(reader.pages)}, Text length: {len(text)}")
    for line in text.splitlines()[:15]:
        print("  ", line)
