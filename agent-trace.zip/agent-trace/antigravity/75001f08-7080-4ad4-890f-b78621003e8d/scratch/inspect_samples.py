import csv
import json

with open('dataset/sample_deletion_requests.csv', 'r', encoding='utf-8') as f:
    requests = list(csv.DictReader(f))

with open('dataset/sample_output.csv', 'r', encoding='utf-8') as f:
    outputs = list(csv.DictReader(f))

req_by_id = {r['case_id']: r for r in requests}

print(f"Total sample cases: {len(requests)}")
for out in outputs:
    cid = out['case_id']
    req = req_by_id[cid]
    status = out['deletion_status']
    steps = json.loads(out['steps_json'])
    print(f"\n--- {cid} ---")
    print(f"Email: {req['email']} | Req at: {req['requested_at']} | Reported: {req['reported_status']} at {req['reported_at']} | Audit at: {req['audit_at']}")
    print(f"Request: {req['request_text']}")
    print(f"Status: {status} | Steps count: {len(steps)}")
    for s in steps:
        print(f"  [{s.get('phase')}] {s.get('operation')} on {s.get('system_id')}:{s.get('resource_id')} (state={s.get('state')}, evidence={s.get('evidence_id')})")
