import sys
sys.stdout.reconfigure(encoding='utf-8')

import csv

with open('dataset/deletion_requests.csv', 'r', encoding='utf-8') as f:
    requests = list(csv.DictReader(f))

# Let's inspect cases that might mention keep, active, continue, export, copy, etc.
candidates = []
for r in requests:
    text = r['request_text'].lower()
    if any(phrase in text for phrase in [
        'leave the account', 'keep the account', 'continue using', 'in place',
        'portable format', 'copy of last year', 'replace it with the new one',
        'opt out of marketing', 'unsubscribe', 'access request', 'download my data',
        'export my data', 'change the email'
    ]):
        candidates.append(r)

print(f"Candidates for NOT_APPLICABLE: {len(candidates)}")
for r in candidates:
    print(f"{r['case_id']} | {r['email']} | {r['request_text']}")
