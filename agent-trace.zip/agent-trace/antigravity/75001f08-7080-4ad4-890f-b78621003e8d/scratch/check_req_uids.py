import csv
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/deletion_requests.csv', 'r', encoding='utf-8') as f:
    requests = list(csv.DictReader(f))

with open('dataset/user_identities.csv', 'r', encoding='utf-8') as f:
    identities = {r['email'].lower(): r['user_id'] for r in csv.DictReader(f)}

with open('dataset/user_audit_log.csv', 'r', encoding='utf-8') as f:
    for r in csv.DictReader(f):
        if r['field_name'] == 'email':
            for e in [r['old_value'], r['new_value']]:
                if e:
                    identities[e.lower()] = r['user_id']

matched_uids = []
unmatched = []
for r in requests:
    cid = r['case_id']
    e = r['email'].lower()
    uid = identities.get(e)
    if uid:
        matched_uids.append((cid, e, uid))
    else:
        unmatched.append((cid, e))

print(f"Total requests: {len(requests)}")
print(f"Matched user_ids: {len(matched_uids)}")
print(f"Unmatched: {len(unmatched)}")
if unmatched:
    print("Sample unmatched:", unmatched[:5])
