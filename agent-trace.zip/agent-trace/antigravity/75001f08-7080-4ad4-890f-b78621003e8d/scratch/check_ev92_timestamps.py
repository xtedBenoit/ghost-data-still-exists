import json
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('dataset/evidence/records/service_resource_export_20260915_114455.json', 'r', encoding='utf-8') as f:
    d = json.load(f)['service_exports']

print("Account profile lookups in ev_92:")
for p in d['account_service']['profile_lookups']:
    print(f"  {p['observed_at']} | {p['resource_id']} | code={p['status_code']}")

print("\nAnalytics profiles in ev_92:")
for a in d['analytics_platform']['profiles']:
    print(f"  {a['observed_at']} | {a['resource_id']} | user={a.get('customer_reference')} | email={a.get('email')}")

print("\nSecurity audit records in ev_92:")
for s in d['security_service']['audit_records']:
    print(f"  {s['observed_at']} | {s['resource_id']} | subject={s.get('subject_reference')}")
